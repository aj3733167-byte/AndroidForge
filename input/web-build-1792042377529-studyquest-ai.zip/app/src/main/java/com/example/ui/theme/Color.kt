package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val QuestIndigo = Color(0xFF4F46E5)
val QuestIndigoLight = Color(0xFF818CF8)
val QuestGold = Color(0xFFF59E0B)
val QuestGoldLight = Color(0xFFFDE68A)
val QuestEmerald = Color(0xFF10B981)
val QuestEmeraldLight = Color(0xFF6EE7B7)
val QuestCrimson = Color(0xFFEF4444)
val QuestPink = Color(0xFFEC4899)
val QuestCyan = Color(0xFF06B6D4)

val Slate950 = Color(0xFF0A0F1D)
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)
