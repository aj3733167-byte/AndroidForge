package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.JsonClass

@Entity(tableName = "courses")
@JsonClass(generateAdapter = true)
data class CourseEntity(
    @PrimaryKey val id: String,
    val title: String,
    val subject: String,
    val targetClass: String,
    val language: String,
    val syllabusText: String,
    val examFormat: String,
    val totalTopics: Int = 0,
    val completedTopics: Int = 0,
    val level: Int = 1,
    val xp: Int = 0,
    val coins: Int = 50,
    val streakDays: Int = 1,
    val lastStudiedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chapters")
@JsonClass(generateAdapter = true)
data class ChapterEntity(
    @PrimaryKey val id: String,
    val courseId: String,
    val chapterNumber: Int,
    val title: String,
    val description: String,
    val isUnlocked: Boolean = true
)

@Entity(tableName = "topics")
@JsonClass(generateAdapter = true)
data class TopicEntity(
    @PrimaryKey val id: String,
    val courseId: String,
    val chapterId: String,
    val chapterNumber: Int,
    val title: String,
    val subtopics: String, // Comma separated or brief list
    val keyFormulas: String,
    val keyDefinitions: String,
    val status: String = "AVAILABLE", // LOCKED, AVAILABLE, IN_PROGRESS, MASTERED
    val masteryPercent: Int = 0,
    val difficulty: String = "MEDIUM", // EASY, MEDIUM, HARD
    val orderIndex: Int = 0
)

@Entity(tableName = "mistakes")
@JsonClass(generateAdapter = true)
data class MistakeEntity(
    @PrimaryKey val id: String,
    val courseId: String,
    val topicId: String,
    val topicTitle: String,
    val question: String,
    val userAnswer: String,
    val correctAnswer: String,
    val whyWrong: String,
    val conceptExplanation: String,
    val memoryTrick: String,
    val timestamp: Long = System.currentTimeMillis(),
    val revisionCount: Int = 0,
    val isMastered: Boolean = false
)

@Entity(tableName = "chat_messages")
@JsonClass(generateAdapter = true)
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val courseId: String,
    val sender: String, // "USER" or "AI"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_profile")
@JsonClass(generateAdapter = true)
data class UserProfileEntity(
    @PrimaryKey val id: String = "current_user",
    val preferredLanguage: String = "Hinglish", // "Hindi", "English", "Hinglish"
    val explanationStyle: String = "From Basics", // "From Basics", "Detailed", "Brief"
    val totalXp: Int = 0,
    val totalCoins: Int = 100,
    val currentStreak: Int = 1,
    val activeCourseId: String = ""
)

// In-memory UI models for interactive learning & quizzes
data class LessonContent(
    val topicTitle: String,
    val introduction: String,
    val coreConcept: String,
    val realWorldAnalogy: String,
    val clearExamples: List<String>,
    val difficultPartsDeepDive: String,
    val formulasOrRules: List<String>,
    val checkpointQuestion: String,
    val checkpointOptions: List<String>,
    val checkpointCorrectIndex: Int,
    val checkpointExplanation: String
)

data class QuizQuestion(
    val id: String,
    val topicTitle: String,
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
    val whyWrongMap: Map<Int, String> = emptyMap(),
    val memoryTrick: String = "",
    val difficulty: String = "MEDIUM"
)

data class WrittenEvaluation(
    val score: Int,
    val maxScore: Int,
    val feedback: String,
    val modelAnswer: String,
    val strengths: List<String>,
    val areasToImprove: List<String>
)

data class FlashcardItem(
    val id: String,
    val frontPrompt: String,
    val backAnswer: String,
    val category: String, // Formula, Definition, Concept, Date
    val masteryLevel: Int = 0
)
