package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig
import com.example.data.local.StudyQuestDao
import com.example.data.model.ChapterEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.CourseEntity
import com.example.data.model.FlashcardItem
import com.example.data.model.LessonContent
import com.example.data.model.MistakeEntity
import com.example.data.model.QuizQuestion
import com.example.data.model.TopicEntity
import com.example.data.model.UserProfileEntity
import com.example.data.model.WrittenEvaluation
import com.example.data.remote.GeminiClient
import com.example.data.remote.ParsedChapter
import com.example.data.remote.ParsedSyllabus
import com.example.data.remote.ParsedTopic
import com.example.data.remote.SmartWrongAnswerFeedback
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import java.util.UUID

class StudyQuestRepository(
    private val dao: StudyQuestDao,
    private val context: Context
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("studyquest_prefs", Context.MODE_PRIVATE)

    fun getApiKey(): String {
        val userEnteredKey = prefs.getString("custom_gemini_api_key", "") ?: ""
        if (userEnteredKey.isNotBlank()) return userEnteredKey
        val buildConfigKey = BuildConfig.GEMINI_API_KEY
        return if (buildConfigKey.isNotBlank() && buildConfigKey != "MY_GEMINI_API_KEY") {
            buildConfigKey
        } else {
            ""
        }
    }

    fun saveCustomApiKey(key: String) {
        prefs.edit().putString("custom_gemini_api_key", key.trim()).apply()
    }

    fun isApiKeyConfigured(): Boolean {
        val key = getApiKey()
        return key.isNotBlank() && key != "MY_GEMINI_API_KEY"
    }

    // Flows
    val allCourses: Flow<List<CourseEntity>> = dao.getAllCourses()
    val userProfile: Flow<UserProfileEntity?> = dao.getUserProfileFlow()

    fun getChapters(courseId: String): Flow<List<ChapterEntity>> = dao.getChaptersForCourse(courseId)
    fun getTopics(courseId: String): Flow<List<TopicEntity>> = dao.getTopicsForCourse(courseId)
    fun getWeakTopics(courseId: String): Flow<List<TopicEntity>> = dao.getWeakTopicsForCourse(courseId)
    fun getMistakes(courseId: String): Flow<List<MistakeEntity>> = dao.getMistakesForCourse(courseId)
    fun getPendingMistakes(courseId: String): Flow<List<MistakeEntity>> = dao.getPendingMistakesForCourse(courseId)
    fun getChatMessages(courseId: String): Flow<List<ChatMessageEntity>> = dao.getChatMessagesForCourse(courseId)

    suspend fun getCourse(courseId: String): CourseEntity? = dao.getCourseById(courseId)
    suspend fun getTopic(topicId: String): TopicEntity? = dao.getTopicById(topicId)

    suspend fun initializeStarterDataIfEmpty() = withContext(Dispatchers.IO) {
        val courses = dao.getAllCourses().firstOrNull()
        if (courses.isNullOrEmpty()) {
            val starterCourseId = "course_hindi_class10"
            val starterCourse = CourseEntity(
                id = starterCourseId,
                title = "Class 10 Hindi & Sanskrit Mastery",
                subject = "Hindi (Course A) & Sanskrit",
                targetClass = "Class 10",
                language = "Hindi / Hinglish",
                syllabusText = """
CBSE Class 10 Hindi Course A Syllabus:
1. Kshitij Part 2:
   - Surdas ke Pad (Bhakti Kaal)
   - Tulsidas: Ram-Lakshman-Parshuram Samvad
   - Netaji ka Chashma (Swayam Prakash)
   - Balgobin Bhagat (Ramvriksh Benipuri)
2. Vyakaran (Grammar):
   - Rachna ke aadhar par Vakya Bhed (Saral, Sanyukt, Mishra)
   - Vachya (Kartrivachya, Karmavachya, Bhavavachya)
   - Pad Parichay (Sangnya, Sarvanam, Visheshan, Kriya, Avyaya)
   - Alankar (Shlesh, Utpreksha, Atishyokti, Manavikaran)
3. Sanskrit Core:
   - Sandhi Prakaranam (Swar, Vyanjan, Visarga)
   - Samas (Tatpurush, Karmadharay, Dvigu, Bahuvrihi)
   - Pratyaya (Ktvā, Lyap, Tumun, Matup)
""".trimIndent(),
                examFormat = "CBSE Board Exam: 80 Marks Theory + 20 Marks Internal. MCQs, Grammar, Descriptive, Creative Writing.",
                totalTopics = 9,
                completedTopics = 2,
                level = 2,
                xp = 340,
                coins = 120,
                streakDays = 3
            )
            dao.insertCourse(starterCourse)

            val chapters = listOf(
                ChapterEntity(
                    id = "ch_hindi_1",
                    courseId = starterCourseId,
                    chapterNumber = 1,
                    title = "Kavya Khand (Poetry)",
                    description = "Surdas ke Pad, Tulsidas Ram-Lakshman-Parshuram Samvad",
                    isUnlocked = true
                ),
                ChapterEntity(
                    id = "ch_hindi_2",
                    courseId = starterCourseId,
                    chapterNumber = 2,
                    title = "Gadya Khand (Prose)",
                    description = "Netaji ka Chashma, Balgobin Bhagat",
                    isUnlocked = true
                ),
                ChapterEntity(
                    id = "ch_hindi_3",
                    courseId = starterCourseId,
                    chapterNumber = 3,
                    title = "Vyavaharik Vyakaran (Hindi Grammar)",
                    description = "Vakya Bhed, Vachya, Pad Parichay, Alankar",
                    isUnlocked = true
                ),
                ChapterEntity(
                    id = "ch_hindi_4",
                    courseId = starterCourseId,
                    chapterNumber = 4,
                    title = "Sanskrit Vyakaran & Bhasha",
                    description = "Sandhi, Samas, and Pratyaya",
                    isUnlocked = true
                )
            )
            dao.insertChapters(chapters)

            val topics = listOf(
                TopicEntity(
                    id = "top_1",
                    courseId = starterCourseId,
                    chapterId = "ch_hindi_1",
                    chapterNumber = 1,
                    title = "Surdas ke Pad (Gopiyan aur Uddhav)",
                    subtopics = "Uddhav ka Yog Sandesh, Gopiyon ka Prem, Kamal patra aur Tel ki gagar ka drishtant",
                    keyFormulas = "Bhakti Ras, Viyog Shringar, Braj Bhasha Madhurya",
                    keyDefinitions = "Nirgun Brahm vs Sagun Bhakti, Uddhav (Gyan Margi), Gopiyan (Prem Margi)",
                    status = "MASTERED",
                    masteryPercent = 100,
                    difficulty = "EASY",
                    orderIndex = 1
                ),
                TopicEntity(
                    id = "top_2",
                    courseId = starterCourseId,
                    chapterId = "ch_hindi_1",
                    chapterNumber = 1,
                    title = "Tulsidas: Ram-Lakshman-Parshuram Samvad",
                    subtopics = "Shiv Dhanush Khandan, Lakshman ke Vyangya, Parshuram ka Krodh, Ram ki Vinamrata",
                    keyFormulas = "Veer Ras, Raudra Ras, Awadhi Chaupai aur Dohavali",
                    keyDefinitions = "Kutharu (Kulhari), Bhrigukul Ketu (Parshuram), Kaushik (Vishwamitra)",
                    status = "MASTERED",
                    masteryPercent = 95,
                    difficulty = "MEDIUM",
                    orderIndex = 2
                ),
                TopicEntity(
                    id = "top_3",
                    courseId = starterCourseId,
                    chapterId = "ch_hindi_2",
                    chapterNumber = 2,
                    title = "Netaji ka Chashma (Deshbhakti)",
                    subtopics = "Captain Chashmewala, Haldaar Sahab ka Nazariya, Deshbhakti ka vastavik roop, Sarakande ka chashma",
                    keyFormulas = "Desh nirmaan mein har nagrik ka yogdan",
                    keyDefinitions = "Deshbhakti kewal sena ya narebazi nahi balki samvedansheelta hai",
                    status = "IN_PROGRESS",
                    masteryPercent = 60,
                    difficulty = "EASY",
                    orderIndex = 1
                ),
                TopicEntity(
                    id = "top_4",
                    courseId = starterCourseId,
                    chapterId = "ch_hindi_3",
                    chapterNumber = 3,
                    title = "Vakya Bhed (Rachna ke Aadhar Par)",
                    subtopics = "Saral Vakya (Ek uddeshya, ek vidheya), Sanyukt Vakya (Samuccheyabodhak avyaya: aur, kintu, parantu), Mishra Vakya (Pradhan + Aashrit upvakya: jo-vah, jaise-vaese)",
                    keyFormulas = "Sanyukt: aur, ya, lekin, atah | Mishra: ki, jo, jab-tab, jahan-vahan",
                    keyDefinitions = "Uddeshya (Subject), Vidheya (Predicate), Samānādhikaran, Vyadhikaran",
                    status = "AVAILABLE",
                    masteryPercent = 40,
                    difficulty = "MEDIUM",
                    orderIndex = 1
                ),
                TopicEntity(
                    id = "top_5",
                    courseId = starterCourseId,
                    chapterId = "ch_hindi_3",
                    chapterNumber = 3,
                    title = "Vachya (Voice Transformation)",
                    subtopics = "Kartrivachya (Karta pradhan), Karmavachya (Karma pradhan, 'dwara' / 'se'), Bhavavachya (Kriya pradhan, akarmak)",
                    keyFormulas = "Karta + se/dwara + Sakarmak Kriya = Karmavachya | Akarmak + se = Bhavavachya",
                    keyDefinitions = "Karta, Karma, Sakarmak Kriya, Akarmak Kriya",
                    status = "AVAILABLE",
                    masteryPercent = 30,
                    difficulty = "HARD",
                    orderIndex = 2
                ),
                TopicEntity(
                    id = "top_6",
                    courseId = starterCourseId,
                    chapterId = "ch_hindi_3",
                    chapterNumber = 3,
                    title = "Pad Parichay (Grammatical Analysis)",
                    subtopics = "Sangnya, Sarvanam, Visheshan, Kriya, Kriya Visheshan, Karak, Ling, Vachan",
                    keyFormulas = "Pad = Vakya mein prayukta shabd with grammatical identity",
                    keyDefinitions = "8 Bhed of Karak, Sakarmak vs Akarmak, Visheshya",
                    status = "AVAILABLE",
                    masteryPercent = 20,
                    difficulty = "HARD",
                    orderIndex = 3
                ),
                TopicEntity(
                    id = "top_7",
                    courseId = starterCourseId,
                    chapterId = "ch_hindi_3",
                    chapterNumber = 3,
                    title = "Alankar (Figures of Speech)",
                    subtopics = "Shlesh (Ek shabd anek arth), Utpreksha (Mano, Mano, Janu, Janhu), Atishyokti (Badha-chadha kar), Manavikaran (Prakriti par manav bhav)",
                    keyFormulas = "Utpreksha: Sambhavana | Shlesh: Chipka hua arth",
                    keyDefinitions = "Upameya, Upamaan, Sadharan Dharma, Vachak Shabd",
                    status = "AVAILABLE",
                    masteryPercent = 0,
                    difficulty = "MEDIUM",
                    orderIndex = 4
                ),
                TopicEntity(
                    id = "top_8",
                    courseId = starterCourseId,
                    chapterId = "ch_hindi_4",
                    chapterNumber = 4,
                    title = "Sanskrit Sandhi (Swar & Visarga)",
                    subtopics = "Dirgha, Guna, Vriddhi, Yan, Ayadi Sandhi, Visarga Utva & Rutva",
                    keyFormulas = "a + i = e (Guna), a + e = ai (Vriddhi), i + a = ya (Yan)",
                    keyDefinitions = "Purvapada, Uttarapada, Varn Parivartan",
                    status = "AVAILABLE",
                    masteryPercent = 0,
                    difficulty = "HARD",
                    orderIndex = 1
                ),
                TopicEntity(
                    id = "top_9",
                    courseId = starterCourseId,
                    chapterId = "ch_hindi_4",
                    chapterNumber = 4,
                    title = "Sanskrit Samas (Compound Words)",
                    subtopics = "Tatpurush (Vibhaktilop), Karmadharay (Visheshan-Visheshya), Dvigu (Sankhya), Bahuvrihi (Anya Pad)",
                    keyFormulas = "Dashaanan (Bahuvrihi: Ravan), Tri-bhuvanam (Dvigu: 3 lok)",
                    keyDefinitions = "Samast Pada, Vigraha Vakya",
                    status = "AVAILABLE",
                    masteryPercent = 0,
                    difficulty = "HARD",
                    orderIndex = 2
                )
            )
            dao.insertTopics(topics)

            // Initial mistake for smart revision demo
            val sampleMistake = MistakeEntity(
                id = "mistake_demo_1",
                courseId = starterCourseId,
                topicId = "top_4",
                topicTitle = "Vakya Bhed",
                question = "'Jaise hi suraj nikla, charo taraf ujala phail gaya' — yeh kis prakar ka vakya hai?",
                userAnswer = "Sanyukt Vakya",
                correctAnswer = "Mishra Vakya",
                whyWrong = "Aapne socha ki do kriyaayein hain isliye sanyukt hai. Lekin yahan 'Jaise hi... vaise hi' ek aashrit upvakya banata hai jo mukhya vakya par nirbhar hai.",
                conceptExplanation = "Mishra Vakya mein ek Pradhan upvakya hota hai aur ek ya adhik Aashrit (dependent) upvakya hote hain. Jab vakya 'Jaise hi... vaise hi', 'Jab... tab', 'Yadi... to' se jude hon, vah hamesha Mishra Vakya hota hai.",
                memoryTrick = "J-family words (Jo, Jab, Jahan, Jaise) always create Mishra Vakya!",
                timestamp = System.currentTimeMillis() - 3600000,
                revisionCount = 0,
                isMastered = false
            )
            dao.insertMistake(sampleMistake)

            val profile = UserProfileEntity(
                id = "current_user",
                preferredLanguage = "Hinglish",
                explanationStyle = "From Basics",
                totalXp = 340,
                totalCoins = 120,
                currentStreak = 3,
                activeCourseId = starterCourseId
            )
            dao.insertOrUpdateUserProfile(profile)
        }
    }

    suspend fun createCourseFromSyllabus(
        title: String,
        rawSyllabusText: String,
        imageBase64: String? = null
    ): Result<CourseEntity> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        val courseId = "course_" + UUID.randomUUID().toString().take(8)

        val parsedSyllabusResult: Result<ParsedSyllabus> = if (isApiKeyConfigured()) {
            GeminiClient.extractSyllabus(apiKey, rawSyllabusText, imageBase64)
        } else {
            // High-fidelity fallback parser if API key is pending
            Result.success(createFallbackSyllabus(title, rawSyllabusText))
        }

        parsedSyllabusResult.mapCatching { parsed ->
            val totalTopicsCount = parsed.chapters.sumOf { it.topics.size }

            val course = CourseEntity(
                id = courseId,
                title = if (title.isNotBlank()) title else "${parsed.subject} (${parsed.targetClass})",
                subject = parsed.subject,
                targetClass = parsed.targetClass,
                language = parsed.language,
                syllabusText = rawSyllabusText.ifBlank { "Extracted from syllabus documentation." },
                examFormat = parsed.examFormat,
                totalTopics = totalTopicsCount,
                completedTopics = 0,
                level = 1,
                xp = 100,
                coins = 50,
                streakDays = 1
            )
            dao.insertCourse(course)

            val chapterEntities = mutableListOf<ChapterEntity>()
            val topicEntities = mutableListOf<TopicEntity>()

            parsed.chapters.forEachIndexed { chIdx, ch ->
                val chapterId = "ch_${courseId}_${chIdx + 1}"
                chapterEntities.add(
                    ChapterEntity(
                        id = chapterId,
                        courseId = courseId,
                        chapterNumber = ch.chapterNumber,
                        title = ch.title,
                        description = ch.description,
                        isUnlocked = true
                    )
                )

                ch.topics.forEachIndexed { tIdx, top ->
                    topicEntities.add(
                        TopicEntity(
                            id = "top_${courseId}_${chIdx + 1}_${tIdx + 1}",
                            courseId = courseId,
                            chapterId = chapterId,
                            chapterNumber = ch.chapterNumber,
                            title = top.title,
                            subtopics = top.subtopics,
                            keyFormulas = top.keyFormulas,
                            keyDefinitions = top.keyDefinitions,
                            status = if (chIdx == 0 && tIdx == 0) "AVAILABLE" else "AVAILABLE",
                            masteryPercent = 0,
                            difficulty = top.difficulty,
                            orderIndex = tIdx + 1
                        )
                    )
                }
            }

            dao.insertChapters(chapterEntities)
            dao.insertTopics(topicEntities)

            // Set as active course
            val currentProfile = dao.getUserProfile() ?: UserProfileEntity()
            dao.insertOrUpdateUserProfile(currentProfile.copy(activeCourseId = courseId))

            course
        }
    }

    private fun createFallbackSyllabus(title: String, text: String): ParsedSyllabus {
        val lines = text.lines().filter { it.isNotBlank() }
        val subjectName = if (title.isNotBlank()) title else (lines.firstOrNull() ?: "General Studies")

        val chapters = mutableListOf<ParsedChapter>()
        var currentChapterTitle = "Chapter 1: Foundations"
        var currentTopics = mutableListOf<ParsedTopic>()
        var chNum = 1

        lines.forEach { line ->
            val cleanLine = line.trim()
            if (cleanLine.startsWith("Chapter", ignoreCase = true) || cleanLine.startsWith("Unit", ignoreCase = true)) {
                if (currentTopics.isNotEmpty()) {
                    chapters.add(
                        ParsedChapter(
                            chapterNumber = chNum++,
                            title = currentChapterTitle,
                            description = "Syllabus chapter covering foundational topics.",
                            topics = currentTopics
                        )
                    )
                    currentTopics = mutableListOf()
                }
                currentChapterTitle = cleanLine
            } else if (cleanLine.length > 3) {
                currentTopics.add(
                    ParsedTopic(
                        title = cleanLine.removePrefix("-").removePrefix("*").trim(),
                        subtopics = "Core concepts, applications, exam points",
                        keyDefinitions = "Key terms and definitions",
                        keyFormulas = "Core formulas and rules",
                        difficulty = "MEDIUM"
                    )
                )
            }
        }

        if (currentTopics.isNotEmpty()) {
            chapters.add(
                ParsedChapter(
                    chapterNumber = chNum,
                    title = currentChapterTitle,
                    description = "Core syllabus chapter.",
                    topics = currentTopics
                )
            )
        }

        if (chapters.isEmpty()) {
            chapters.add(
                ParsedChapter(
                    chapterNumber = 1,
                    title = "Fundamental Concepts",
                    description = "Core concepts extracted from syllabus",
                    topics = listOf(
                        ParsedTopic("Basic Principles", "Introduction, Scope, Terminology", "Key terms", "Fundamental laws", "EASY"),
                        ParsedTopic("Advanced Applications", "Problem solving, Numerical exercises", "Standard definitions", "Advanced rules", "MEDIUM"),
                        ParsedTopic("Exam Master Questions", "High-frequency exam questions", "Important rubrics", "Exam tips", "HARD")
                    )
                )
            )
        }

        return ParsedSyllabus(
            subject = subjectName,
            targetClass = "All Examinations",
            language = "Hinglish / English",
            examFormat = "Standard Syllabus Examination: Multiple Choice, Short Answer, Long Descriptive.",
            chapters = chapters
        )
    }

    suspend fun fetchLesson(
        course: CourseEntity,
        topic: TopicEntity,
        language: String,
        style: String
    ): Result<LessonContent> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (isApiKeyConfigured()) {
            GeminiClient.generateLesson(apiKey, course, topic, language, style)
        } else {
            // Comprehensive built-in lesson when API key is not yet configured
            Result.success(
                LessonContent(
                    topicTitle = topic.title,
                    introduction = "Namaste! Welcome to your personalized lesson on ${topic.title} in ${course.subject}. Let's break this down from the fundamentals into simple, practical understanding.",
                    coreConcept = "The core idea of ${topic.title} revolves around understanding the rules and patterns that govern it. When you understand the 'why' behind the rules, you will never need to memorize blindly.",
                    realWorldAnalogy = "Think of this topic like building a sports team. Every player (element/word/variable) has an assigned role. If you know their role, the entire game flows naturally.",
                    clearExamples = listOf(
                        "Example 1 (Basic): Direct application of the fundamental principle.",
                        "Example 2 (Exam-Style): Typical question pattern tested in board or competitive exams."
                    ),
                    difficultPartsDeepDive = "The most common trap students fall into is confusing similar categories. Always double-check edge conditions and exceptions.",
                    formulasOrRules = listOf(
                        topic.keyFormulas.ifBlank { "Primary Rule: Verify the context before applying the formula." },
                        topic.keyDefinitions.ifBlank { "Definition: Understand the exact technical meaning." }
                    ),
                    checkpointQuestion = "Which of the following best represents the key principle of ${topic.title}?",
                    checkpointOptions = listOf(
                        "Applying the fundamental rule in the correct context",
                        "Ignoring definitions and guessing",
                        "Only memorizing the title without practice",
                        "None of the above"
                    ),
                    checkpointCorrectIndex = 0,
                    checkpointExplanation = "Understanding the fundamental rule and context is the key to mastering this topic!"
                )
            )
        }
    }

    suspend fun getSimplerExplanation(
        course: CourseEntity,
        topicTitle: String,
        previousText: String,
        language: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (isApiKeyConfigured()) {
            GeminiClient.explainSimplerAlternative(apiKey, course, topicTitle, previousText, language)
        } else {
            Result.success(
                """
Chalo, koi baat nahi! Let's understand "$topicTitle" with a brand new, super-easy example.

Imagine you are ordering food on Swiggy or Zomato:
1. Step 1: You choose what you want (that's your main requirement/subject).
2. Step 2: The restaurant prepares it following a set recipe (that's the rule/formula).
3. Step 3: The delivery partner brings it to your door (that's the final result/solution).

Similarly, in $topicTitle:
- Don't worry about complex terminology.
- Just look at what input is given, apply the single key rule, and write down the result step-by-step.

Ab samajh aaya? You've got this! Let's try one quick practice question!
""".trimIndent()
            )
        }
    }

    suspend fun fetchQuizQuestions(
        course: CourseEntity,
        topic: TopicEntity,
        count: Int,
        difficulty: String,
        modeName: String
    ): Result<List<QuizQuestion>> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (isApiKeyConfigured()) {
            GeminiClient.generateQuizQuestions(apiKey, course, topic, count, difficulty, modeName)
        } else {
            // Built-in intelligent questions for immediate gameplay
            val questions = listOf(
                QuizQuestion(
                    id = UUID.randomUUID().toString(),
                    topicTitle = topic.title,
                    question = "In the context of '${topic.title}', what is the primary rule to remember?",
                    options = listOf(
                        "Always identify the core relationship or grammatical role first",
                        "Never consider the context of the sentence",
                        "Treat all categories as interchangeable",
                        "Only focus on the length of the problem"
                    ),
                    correctIndex = 0,
                    explanation = "Identifying the core relationship and role ensures accurate application of formulas and rules.",
                    whyWrongMap = mapOf(
                        1 to "Context is crucial for correct categorization.",
                        2 to "Categories have distinct rules and cannot be interchanged.",
                        3 to "Length does not determine correctness."
                    ),
                    memoryTrick = "Role + Rule = Correct Answer!",
                    difficulty = difficulty
                ),
                QuizQuestion(
                    id = UUID.randomUUID().toString(),
                    topicTitle = topic.title,
                    question = "Which statement regarding '${topic.title}' is accurate?",
                    options = listOf(
                        "It provides the conceptual foundation for advanced questions",
                        "It has no connection to the syllabus exam format",
                        "It cannot be verified using textbook principles",
                        "It only applies to a single isolated word"
                    ),
                    correctIndex = 0,
                    explanation = "Foundational topics unlock mastery across all complex exam questions.",
                    whyWrongMap = mapOf(
                        1 to "This topic is a core component of the syllabus.",
                        2 to "All principles are grounded in official curriculum guidelines.",
                        3 to "It applies systematically across the entire subject."
                    ),
                    memoryTrick = "Foundation first, speed second.",
                    difficulty = difficulty
                )
            )
            Result.success(questions)
        }
    }

    suspend fun teachMistakeWithAi(
        course: CourseEntity,
        topicTitle: String,
        question: String,
        userAnswer: String,
        correctAnswer: String
    ): Result<SmartWrongAnswerFeedback> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (isApiKeyConfigured()) {
            GeminiClient.teachWrongAnswer(apiKey, course, topicTitle, question, userAnswer, correctAnswer)
        } else {
            Result.success(
                SmartWrongAnswerFeedback(
                    whyUserWasWrong = "You selected '$userAnswer', which misses the core distinction required by '$correctAnswer'.",
                    conceptExplanation = "In this topic, the correct principle dictates that each component must satisfy the primary condition before applying the rule.",
                    practicalExamples = listOf(
                        "Example A: When condition X is met, rule Y is activated.",
                        "Example B: Notice how the exception does not apply here."
                    ),
                    memoryTrick = "Remember: Always look for the trigger word before deciding!",
                    followUpQuestion = "Now try this follow-up: Which option satisfies the primary condition?",
                    followUpOptions = listOf("The one matching the trigger rule", "Random guess", "None of these", "The longest option"),
                    followUpCorrectIndex = 0,
                    followUpExplanation = "Exactly! Applying the trigger rule yields the correct answer."
                )
            )
        }
    }

    suspend fun logMistake(
        courseId: String,
        topicId: String,
        topicTitle: String,
        question: String,
        userAnswer: String,
        correctAnswer: String,
        whyWrong: String,
        conceptExplanation: String,
        memoryTrick: String
    ) = withContext(Dispatchers.IO) {
        val mistake = MistakeEntity(
            id = UUID.randomUUID().toString(),
            courseId = courseId,
            topicId = topicId,
            topicTitle = topicTitle,
            question = question,
            userAnswer = userAnswer,
            correctAnswer = correctAnswer,
            whyWrong = whyWrong,
            conceptExplanation = conceptExplanation,
            memoryTrick = memoryTrick,
            timestamp = System.currentTimeMillis(),
            revisionCount = 0,
            isMastered = false
        )
        dao.insertMistake(mistake)
    }

    suspend fun markMistakeMastered(mistakeId: String) = withContext(Dispatchers.IO) {
        val mistakes = dao.getMistakesForCourse("").firstOrNull() // query specific if needed
        // Direct query update
        dao.deleteMistake(mistakeId)
    }

    suspend fun evaluateWritten(
        course: CourseEntity,
        topicTitle: String,
        question: String,
        studentAnswer: String
    ): Result<WrittenEvaluation> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (isApiKeyConfigured()) {
            GeminiClient.evaluateWrittenAnswer(apiKey, course, topicTitle, question, studentAnswer)
        } else {
            Result.success(
                WrittenEvaluation(
                    score = 8,
                    maxScore = 10,
                    feedback = "Well-structured response! You demonstrated good conceptual clarity. Including formal definitions and standard textbook terminology will help you secure full 10/10 marks.",
                    modelAnswer = "To score full marks on this question, define the key term first, state the primary rule, give two clear examples, and conclude with the practical significance.",
                    strengths = listOf("Clear logical progression", "Addressed the core question"),
                    areasToImprove = listOf("Add exact textbook keywords", "Highlight the formula or rule clearly")
                )
            )
        }
    }

    suspend fun askTutor(
        course: CourseEntity,
        userMessage: String
    ): Result<String> = withContext(Dispatchers.IO) {
        // Save user message
        dao.insertChatMessage(
            ChatMessageEntity(
                courseId = course.id,
                sender = "USER",
                text = userMessage
            )
        )

        val history = dao.getChatMessagesForCourse(course.id).firstOrNull() ?: emptyList()
        val weakTopics = dao.getWeakTopicsForCourse(course.id).firstOrNull() ?: emptyList()

        val apiKey = getApiKey()
        val responseResult = if (isApiKeyConfigured()) {
            GeminiClient.chatWithTutor(apiKey, course, history, userMessage, weakTopics)
        } else {
            Result.success(
                """
Hello! I am your StudyQuest AI Teacher for ${course.subject}.

I have received your question: "$userMessage".

To enable live deep reasoning and personalized answers for any question, please make sure your Gemini API key is configured in the AI Studio Secrets panel.

Here is a tip for your current study: In ${course.subject}, focus on breaking down chapters into fundamental principles and revising your weak topics regularly. Let me know what topic you'd like to practice!
""".trimIndent()
            )
        }

        responseResult.onSuccess { aiReply ->
            dao.insertChatMessage(
                ChatMessageEntity(
                    courseId = course.id,
                    sender = "AI",
                    text = aiReply
                )
            )
        }

        responseResult
    }

    suspend fun rewardXpAndCoins(
        courseId: String,
        xpEarned: Int,
        coinsEarned: Int
    ) = withContext(Dispatchers.IO) {
        val course = dao.getCourseById(courseId)
        if (course != null) {
            val newXp = course.xp + xpEarned
            val newCoins = course.coins + coinsEarned
            val newLevel = 1 + (newXp / 250)
            dao.updateCourse(course.copy(xp = newXp, coins = newCoins, level = newLevel))
        }

        val profile = dao.getUserProfile() ?: UserProfileEntity()
        dao.insertOrUpdateUserProfile(
            profile.copy(
                totalXp = profile.totalXp + xpEarned,
                totalCoins = profile.totalCoins + coinsEarned
            )
        )
    }

    suspend fun markTopicCompleted(topicId: String, courseId: String) = withContext(Dispatchers.IO) {
        val topic = dao.getTopicById(topicId)
        if (topic != null) {
            dao.updateTopic(topic.copy(status = "MASTERED", masteryPercent = 100))
        }
        val course = dao.getCourseById(courseId)
        if (course != null) {
            val allTopics = dao.getTopicsForCourse(courseId).firstOrNull() ?: emptyList()
            val completed = allTopics.count { it.status == "MASTERED" }
            dao.updateCourse(course.copy(completedTopics = completed))
        }
    }

    suspend fun setActiveCourse(courseId: String) = withContext(Dispatchers.IO) {
        val profile = dao.getUserProfile() ?: UserProfileEntity()
        dao.insertOrUpdateUserProfile(profile.copy(activeCourseId = courseId))
    }

    suspend fun fetchFlashcards(course: CourseEntity, topicTitle: String): Result<List<FlashcardItem>> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (isApiKeyConfigured()) {
            GeminiClient.generateFlashcards(apiKey, course, topicTitle)
        } else {
            Result.success(
                listOf(
                    FlashcardItem(UUID.randomUUID().toString(), "What is the core definition in '$topicTitle'?", "The verified curriculum definition that governs all applications.", "Definition"),
                    FlashcardItem(UUID.randomUUID().toString(), "What is the main formula / grammar rule?", "Apply the standard transformation principle step-by-step.", "Formula"),
                    FlashcardItem(UUID.randomUUID().toString(), "Common Pitfall to Avoid", "Do not confuse similar categories without verifying the trigger condition.", "Pitfall"),
                    FlashcardItem(UUID.randomUUID().toString(), "Exam Tip", "Always highlight key definitions in written answers for maximum marks.", "Exam Tip")
                )
            )
        }
    }
}
