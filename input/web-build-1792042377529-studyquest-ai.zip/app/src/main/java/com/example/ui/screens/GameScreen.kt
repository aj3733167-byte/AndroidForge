package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.navigation.GameMode
import com.example.ui.theme.QuestCyan
import com.example.ui.theme.QuestEmerald
import com.example.ui.theme.QuestGold
import com.example.ui.theme.QuestIndigo
import com.example.ui.theme.QuestPink
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950
import com.example.ui.viewmodel.StudyQuestViewModel

@Composable
fun GameScreen(
    topicId: String,
    mode: GameMode,
    viewModel: StudyQuestViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val questions by viewModel.quizQuestions.collectAsState()
    val currentIndex by viewModel.currentQuestionIndex.collectAsState()
    val selectedOption by viewModel.selectedQuizOption.collectAsState()
    val isSubmitted by viewModel.isQuizAnswerSubmitted.collectAsState()
    val isCorrect by viewModel.isQuizAnswerCorrect.collectAsState()
    val smartFeedback by viewModel.smartWrongFeedback.collectAsState()
    val followUpSelected by viewModel.followUpAnswerSelected.collectAsState()
    val followUpCorrect by viewModel.followUpAnswerCorrect.collectAsState()
    val isCompleted by viewModel.isQuizCompleted.collectAsState()
    val isLoading by viewModel.isQuizLoading.collectAsState()
    val hearts by viewModel.survivalHearts.collectAsState()
    val rapidFireSeconds by viewModel.rapidFireSeconds.collectAsState()
    val bossHp by viewModel.bossHp.collectAsState()
    val playerHp by viewModel.playerHp.collectAsState()
    val xpEarned by viewModel.quizXpEarned.collectAsState()
    val coinsEarned by viewModel.quizCoinsEarned.collectAsState()
    val streak by viewModel.quizStreak.collectAsState()

    // Written Challenge State
    val writtenEvaluation by viewModel.writtenEvaluation.collectAsState()
    val isEvaluatingWritten by viewModel.isEvaluatingWritten.collectAsState()
    var writtenAnswerText by remember { mutableStateOf("") }

    LaunchedEffect(topicId, mode) {
        viewModel.startQuiz(topicId, mode)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
    ) {
        // Top App Bar with Game Mode & Stats
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Slate900)
                .padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("game_back_button")) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Column {
                    Text(
                        text = mode.displayName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color.White
                    )
                    Text(
                        text = "Question ${currentIndex + 1} of ${questions.size.coerceAtLeast(1)}",
                        fontSize = 11.sp,
                        color = Color.LightGray
                    )
                }
            }

            // Game Mode Specific Badges
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (mode == GameMode.SURVIVAL) {
                    // Hearts
                    Row(modifier = Modifier.padding(end = 8.dp)) {
                        repeat(3) { index ->
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = "Heart",
                                tint = if (index < hearts) Color(0xFFEF4444) else Slate800,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                } else if (mode == GameMode.RAPID_FIRE) {
                    // Timer
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (rapidFireSeconds <= 5) Color(0xFF7F1D1D) else Slate800
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = if (rapidFireSeconds <= 5) Color.Red else QuestGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${rapidFireSeconds}s",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                } else if (mode == GameMode.BOSS_BATTLE) {
                    // Boss vs Player mini status
                    Text("Boss: $bossHp%", color = Color.Red, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Streak Flame
                if (streak > 1) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF7C2D12),
                        modifier = Modifier.padding(end = 6.dp)
                    ) {
                        Text(
                            text = "${streak}x 🔥",
                            color = Color(0xFFFED7AA),
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = QuestPink)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("AI is crafting challenge questions...", color = Color.LightGray, fontSize = 14.sp)
                }
            }
        } else if (isCompleted) {
            // Quiz Complete / Victory Screen
            QuizVictoryContent(
                mode = mode,
                xpEarned = xpEarned,
                coinsEarned = coinsEarned,
                onRestart = { viewModel.startQuiz(topicId, mode) },
                onExit = onBack
            )
        } else if (mode == GameMode.WRITTEN_CHALLENGE) {
            // Written Answer Challenge
            WrittenChallengeContent(
                topicTitle = questions.firstOrNull()?.topicTitle ?: "Topic Mastery",
                question = questions.firstOrNull()?.question ?: "Explain the fundamental principles and applications.",
                answerText = writtenAnswerText,
                onAnswerChange = { writtenAnswerText = it },
                evaluation = writtenEvaluation,
                isEvaluating = isEvaluatingWritten,
                onSubmit = { viewModel.submitWrittenAnswer(questions.firstOrNull()?.topicTitle ?: "Topic", questions.firstOrNull()?.question ?: "Q", writtenAnswerText) },
                onFinish = onBack
            )
        } else if (questions.isNotEmpty() && currentIndex < questions.size) {
            val currentQ = questions[currentIndex]

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Boss HP Bar in Boss Battle
                if (mode == GameMode.BOSS_BATTLE) {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Slate900),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("👹 Topic Master Boss", fontWeight = FontWeight.Bold, color = Color.Red, fontSize = 13.sp)
                                Text("Boss HP: $bossHp / 100", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { (bossHp / 100f).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = Color.Red,
                                trackColor = Slate800
                            )
                        }
                    }
                }

                // Question Card (Only ONE question shown at a time as required by Rule 7)
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate900),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("quiz_question_card")
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = currentQ.topicTitle,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = QuestPink
                            )
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Slate800
                            ) {
                                Text(
                                    text = currentQ.difficulty,
                                    fontSize = 11.sp,
                                    color = Color.LightGray,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = currentQ.question,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            lineHeight = 24.sp
                        )
                    }
                }

                // 4 Clickable Options
                currentQ.options.forEachIndexed { optIndex, optionText ->
                    val isThisSelected = (selectedOption == optIndex)
                    val isThisCorrect = (optIndex == currentQ.correctIndex)

                    val borderColor = when {
                        !isSubmitted -> if (isThisSelected) QuestCyan else Slate800
                        isThisCorrect -> QuestEmerald
                        isThisSelected -> Color.Red
                        else -> Slate800
                    }

                    val bgColor = when {
                        !isSubmitted -> if (isThisSelected) Slate800 else Slate900
                        isThisCorrect -> Color(0xFF065F46)
                        isThisSelected -> Color(0xFF7F1D1D)
                        else -> Slate900
                    }

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = bgColor,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.5.dp, borderColor, RoundedCornerShape(14.dp))
                            .clickable(enabled = !isSubmitted) {
                                viewModel.submitQuizAnswer(optIndex)
                            }
                            .testTag("quiz_option_$optIndex")
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            isSubmitted && isThisCorrect -> QuestEmerald
                                            isSubmitted && isThisSelected -> Color.Red
                                            else -> Slate800
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${('A' + optIndex)}",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Text(
                                text = optionText,
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = if (isThisSelected) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.weight(1f)
                            )

                            if (isSubmitted && isThisCorrect) {
                                Icon(Icons.Default.CheckCircle, contentDescription = "Correct", tint = QuestEmerald)
                            } else if (isSubmitted && isThisSelected && !isThisCorrect) {
                                Icon(Icons.Default.Close, contentDescription = "Wrong", tint = Color.Red)
                            }
                        }
                    }
                }

                // Post-Answer Feedback
                if (isSubmitted) {
                    if (isCorrect == true) {
                        // Correct Answer Celebration Card
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF065F46)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Correct! +20 XP", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(currentQ.explanation, color = Color.White, fontSize = 13.sp, lineHeight = 19.sp)

                                if (currentQ.memoryTrick.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text("⚡ Pro Tip: ${currentQ.memoryTrick}", color = QuestGold, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    } else {
                        // SMART WRONG-ANSWER TEACHING (Rule 8)
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Slate900),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color.Red),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Lightbulb, contentDescription = null, tint = QuestGold, modifier = Modifier.size(24.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Smart Mistake Breakdown", fontWeight = FontWeight.Black, color = QuestGold, fontSize = 16.sp)
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Why your answer was incorrect
                                if (smartFeedback != null) {
                                    Text("Why Your Answer Was Wrong:", fontWeight = FontWeight.Bold, color = Color(0xFFFCA5A5), fontSize = 13.sp)
                                    Text(smartFeedback!!.whyUserWasWrong, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp))

                                    Text("The Core Concept:", fontWeight = FontWeight.Bold, color = QuestCyan, fontSize = 13.sp)
                                    Text(smartFeedback!!.conceptExplanation, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp))

                                    if (smartFeedback!!.practicalExamples.isNotEmpty()) {
                                        Text("Practical Examples:", fontWeight = FontWeight.Bold, color = QuestEmerald, fontSize = 13.sp)
                                        smartFeedback!!.practicalExamples.forEach { ex ->
                                            Text("• $ex", color = Color(0xFFE2E8F0), fontSize = 12.sp, modifier = Modifier.padding(vertical = 1.dp))
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                    }

                                    if (smartFeedback!!.memoryTrick.isNotBlank()) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color(0xFF78350F).copy(alpha = 0.4f),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text("💡 Memory Trick: ${smartFeedback!!.memoryTrick}", color = QuestGold, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(8.dp))
                                        }
                                        Spacer(modifier = Modifier.height(10.dp))
                                    }

                                    // Follow-up question to test understanding before moving on
                                    Text("Follow-Up Check (Did you get it now?):", fontWeight = FontWeight.Bold, color = QuestPink, fontSize = 13.sp)
                                    Text(smartFeedback!!.followUpQuestion, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(vertical = 4.dp))

                                    smartFeedback!!.followUpOptions.forEachIndexed { fIdx, fOpt ->
                                        val fSelected = (followUpSelected == fIdx)
                                        val fCorrect = (fIdx == smartFeedback!!.followUpCorrectIndex)

                                        val fColor = when {
                                            followUpSelected == null -> Slate800
                                            fCorrect -> Color(0xFF065F46)
                                            fSelected -> Color(0xFF7F1D1D)
                                            else -> Slate800
                                        }

                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = fColor,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 2.dp)
                                                .clickable(enabled = followUpSelected == null) {
                                                    viewModel.answerSmartFollowUp(fIdx)
                                                }
                                        ) {
                                            Text(fOpt, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(8.dp))
                                        }
                                    }
                                } else {
                                    // Fallback if AI call in progress
                                    Text("Correct Answer: ${currentQ.options[currentQ.correctIndex]}", color = QuestEmerald, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(currentQ.explanation, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                                    if (currentQ.memoryTrick.isNotBlank()) {
                                        Text("💡 Memory Rule: ${currentQ.memoryTrick}", color = QuestGold, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                                    }
                                }
                            }
                        }
                    }

                    // Next Question Button
                    Button(
                        onClick = { viewModel.nextQuestion(topicId) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("next_question_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = QuestIndigo),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(
                            text = if (currentIndex + 1 < questions.size) "Next Challenge →" else "Finish Quest 🎉",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun QuizVictoryContent(
    mode: GameMode,
    xpEarned: Int,
    coinsEarned: Int,
    onRestart: () -> Unit,
    onExit: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(QuestGold.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Star, contentDescription = null, tint = QuestGold, modifier = Modifier.size(48.dp))
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("Quest Completed!", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color.White)
            Text("Mode: ${mode.displayName}", fontSize = 14.sp, color = Color.LightGray)

            Spacer(modifier = Modifier.height(20.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Slate900,
                    modifier = Modifier.padding(4.dp)
                ) {
                    Row(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Star, contentDescription = null, tint = QuestCyan)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("+$xpEarned XP", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Slate900,
                    modifier = Modifier.padding(4.dp)
                ) {
                    Row(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = QuestGold)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("+$coinsEarned Coins", color = QuestGold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            Button(
                onClick = onRestart,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = QuestIndigo),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Play Again", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = onExit,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Return to Dashboard", fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

@Composable
private fun WrittenChallengeContent(
    topicTitle: String,
    question: String,
    answerText: String,
    onAnswerChange: (String) -> Unit,
    evaluation: com.example.data.model.WrittenEvaluation?,
    isEvaluating: Boolean,
    onSubmit: () -> Unit,
    onFinish: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Slate900),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(topicTitle, fontWeight = FontWeight.Bold, color = QuestPink, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Text(question, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Type your full answer below. The AI examiner will check definitions, accuracy, clarity, and award partial marks according to examination rubrics.", fontSize = 12.sp, color = Color.LightGray)
            }
        }

        OutlinedTextField(
            value = answerText,
            onValueChange = onAnswerChange,
            placeholder = { Text("Write your detailed answer here...") },
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .testTag("written_answer_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = QuestIndigo,
                unfocusedBorderColor = Slate800,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedContainerColor = Slate900,
                unfocusedContainerColor = Slate900
            ),
            shape = RoundedCornerShape(12.dp)
        )

        Button(
            onClick = onSubmit,
            enabled = !isEvaluating && answerText.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("submit_written_button"),
            colors = ButtonDefaults.buttonColors(containerColor = QuestCyan),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (isEvaluating) {
                CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("AI Evaluating with Marking Rubric...", color = Color.Black, fontWeight = FontWeight.Bold)
            } else {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Submit for AI Evaluation", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }

        if (evaluation != null) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Slate900),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Examiner's Scorecard", fontWeight = FontWeight.Black, fontSize = 16.sp, color = QuestGold)
                        Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFF065F46)) {
                            Text("${evaluation.score} / ${evaluation.maxScore} Marks", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(evaluation.feedback, color = Color.White, fontSize = 13.sp, lineHeight = 20.sp)

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Model Answer for 10/10 Marks:", fontWeight = FontWeight.Bold, color = QuestCyan, fontSize = 13.sp)
                    Text(evaluation.modelAnswer, color = Color(0xFFCBD5E1), fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 2.dp))

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = onFinish,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = QuestIndigo),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Finish & Return", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}
