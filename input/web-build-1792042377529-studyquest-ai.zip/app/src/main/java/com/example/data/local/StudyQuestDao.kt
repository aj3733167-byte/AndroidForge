package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ChapterEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.CourseEntity
import com.example.data.model.MistakeEntity
import com.example.data.model.TopicEntity
import com.example.data.model.UserProfileEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StudyQuestDao {

    // Courses
    @Query("SELECT * FROM courses ORDER BY lastStudiedAt DESC")
    fun getAllCourses(): Flow<List<CourseEntity>>

    @Query("SELECT * FROM courses WHERE id = :courseId LIMIT 1")
    suspend fun getCourseById(courseId: String): CourseEntity?

    @Query("SELECT * FROM courses WHERE id = :courseId LIMIT 1")
    fun getCourseByIdFlow(courseId: String): Flow<CourseEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCourse(course: CourseEntity)

    @Update
    suspend fun updateCourse(course: CourseEntity)

    @Query("DELETE FROM courses WHERE id = :courseId")
    suspend fun deleteCourse(courseId: String)

    // Chapters
    @Query("SELECT * FROM chapters WHERE courseId = :courseId ORDER BY chapterNumber ASC")
    fun getChaptersForCourse(courseId: String): Flow<List<ChapterEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapters(chapters: List<ChapterEntity>)

    // Topics
    @Query("SELECT * FROM topics WHERE courseId = :courseId ORDER BY chapterNumber ASC, orderIndex ASC")
    fun getTopicsForCourse(courseId: String): Flow<List<TopicEntity>>

    @Query("SELECT * FROM topics WHERE chapterId = :chapterId ORDER BY orderIndex ASC")
    fun getTopicsForChapter(chapterId: String): Flow<List<TopicEntity>>

    @Query("SELECT * FROM topics WHERE id = :topicId LIMIT 1")
    suspend fun getTopicById(topicId: String): TopicEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopics(topics: List<TopicEntity>)

    @Update
    suspend fun updateTopic(topic: TopicEntity)

    @Query("SELECT * FROM topics WHERE courseId = :courseId AND (status = 'IN_PROGRESS' OR masteryPercent < 70)")
    fun getWeakTopicsForCourse(courseId: String): Flow<List<TopicEntity>>

    // Mistakes & Revision
    @Query("SELECT * FROM mistakes WHERE courseId = :courseId ORDER BY timestamp DESC")
    fun getMistakesForCourse(courseId: String): Flow<List<MistakeEntity>>

    @Query("SELECT * FROM mistakes WHERE courseId = :courseId AND isMastered = 0 ORDER BY timestamp DESC")
    fun getPendingMistakesForCourse(courseId: String): Flow<List<MistakeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMistake(mistake: MistakeEntity)

    @Update
    suspend fun updateMistake(mistake: MistakeEntity)

    @Query("DELETE FROM mistakes WHERE id = :mistakeId")
    suspend fun deleteMistake(mistakeId: String)

    // Chat History
    @Query("SELECT * FROM chat_messages WHERE courseId = :courseId ORDER BY timestamp ASC")
    fun getChatMessagesForCourse(courseId: String): Flow<List<ChatMessageEntity>>

    @Insert
    suspend fun insertChatMessage(message: ChatMessageEntity)

    @Query("DELETE FROM chat_messages WHERE courseId = :courseId")
    suspend fun clearChatMessages(courseId: String)

    // User Profile
    @Query("SELECT * FROM user_profile WHERE id = 'current_user' LIMIT 1")
    fun getUserProfileFlow(): Flow<UserProfileEntity?>

    @Query("SELECT * FROM user_profile WHERE id = 'current_user' LIMIT 1")
    suspend fun getUserProfile(): UserProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateUserProfile(profile: UserProfileEntity)
}
