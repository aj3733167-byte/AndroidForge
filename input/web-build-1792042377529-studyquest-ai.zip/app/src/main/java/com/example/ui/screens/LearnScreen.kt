package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.QuestionMark
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.navigation.GameMode
import com.example.ui.theme.QuestCyan
import com.example.ui.theme.QuestEmerald
import com.example.ui.theme.QuestGold
import com.example.ui.theme.QuestIndigo
import com.example.ui.theme.QuestPink
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950
import com.example.ui.viewmodel.StudyQuestViewModel

@Composable
fun LearnScreen(
    topicId: String,
    viewModel: StudyQuestViewModel,
    onBack: () -> Unit,
    onStartQuiz: (String, GameMode) -> Unit
) {
    BackHandler { onBack() }

    val activeLesson by viewModel.activeLesson.collectAsState()
    val isLoading by viewModel.isLessonLoading.collectAsState()
    val simplifiedExplanation by viewModel.simplifiedExplanation.collectAsState()
    val isSimplifying by viewModel.isSimplifying.collectAsState()
    val lessonLang by viewModel.lessonLanguage.collectAsState()
    val lessonStyle by viewModel.lessonStyle.collectAsState()
    val selectedOption by viewModel.checkpointAnswerSelected.collectAsState()
    val isCorrect by viewModel.checkpointAnswerCorrect.collectAsState()

    LaunchedEffect(topicId) {
        viewModel.loadLesson(topicId)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
    ) {
        // App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Slate900)
                .padding(horizontal = 8.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("learn_back_button")) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = activeLesson?.topicTitle ?: "AI Lesson",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1
                )
                Text(
                    text = "Personal Step-by-Step AI Teacher",
                    fontSize = 12.sp,
                    color = QuestCyan
                )
            }
        }

        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = QuestIndigo)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("AI Teacher is preparing your lesson...", color = Color.LightGray, fontSize = 14.sp)
                }
            }
        } else if (activeLesson != null) {
            val lesson = activeLesson!!

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Language & Depth Controls (Rule 6: Hindi, English, Hinglish, Basics, Detailed, Brief)
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate900),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("EXPLANATION LANGUAGE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = QuestGold)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
                        ) {
                            listOf("Hinglish", "Hindi", "English").forEach { lang ->
                                FilterChip(
                                    selected = lessonLang == lang,
                                    onClick = { viewModel.setLessonLanguage(lang, topicId) },
                                    label = { Text(lang, fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = QuestIndigo,
                                        selectedLabelColor = Color.White,
                                        containerColor = Slate800,
                                        labelColor = Color.LightGray
                                    )
                                )
                            }
                        }

                        Text("TEACHING STYLE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = QuestCyan)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            listOf("From Basics", "Detailed", "Brief").forEach { style ->
                                FilterChip(
                                    selected = lessonStyle == style,
                                    onClick = { viewModel.setLessonStyle(style, topicId) },
                                    label = { Text(style, fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = QuestPink,
                                        selectedLabelColor = Color.White,
                                        containerColor = Slate800,
                                        labelColor = Color.LightGray
                                    )
                                )
                            }
                        }
                    }
                }

                // 1. Introduction Card
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate900),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.School, contentDescription = null, tint = QuestGold, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("1. Simple Introduction", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = QuestGold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = lesson.introduction,
                            fontSize = 14.sp,
                            color = Color.White,
                            lineHeight = 22.sp
                        )
                    }
                }

                // 2. Core Concept & 3. Real World Analogy
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate900),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lightbulb, contentDescription = null, tint = QuestCyan, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("2. The Core Concept", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = QuestCyan)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = lesson.coreConcept,
                            fontSize = 14.sp,
                            color = Color.White,
                            lineHeight = 22.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF1E1B4B),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("🌟 Everyday Analogy", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = QuestGold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = lesson.realWorldAnalogy,
                                    fontSize = 13.sp,
                                    color = Color(0xFFE2E8F0),
                                    lineHeight = 20.sp
                                )
                            }
                        }
                    }
                }

                // 4. Clear Examples
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate900),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("3. Step-by-Step Examples", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = QuestEmerald)
                        Spacer(modifier = Modifier.height(8.dp))
                        lesson.clearExamples.forEachIndexed { idx, example ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Slate800,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Row(modifier = Modifier.padding(10.dp)) {
                                    Text("${idx + 1}.", fontWeight = FontWeight.Bold, color = QuestEmerald, fontSize = 13.sp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(example, color = Color.White, fontSize = 13.sp, lineHeight = 20.sp)
                                }
                            }
                        }
                    }
                }

                // 5. Rules & Formulas
                if (lesson.formulasOrRules.isNotEmpty()) {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Slate900),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("4. Key Rules, Formulas & Definitions", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = QuestPink)
                            Spacer(modifier = Modifier.height(8.dp))
                            lesson.formulasOrRules.forEach { rule ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFF831843).copy(alpha = 0.3f),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "• $rule",
                                        color = Color(0xFFFBCFE8),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // 6. Common Pitfalls / Tricky Parts
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate900),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("5. Avoiding Common Exam Traps", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFFF87171))
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = lesson.difficultPartsDeepDive,
                            fontSize = 13.sp,
                            color = Color(0xFFE2E8F0),
                            lineHeight = 20.sp
                        )
                    }
                }

                // "Mujhe samajh nahi aaya" Special Feature (Rule 6)
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate900),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Need a different explanation?", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                                Text("Ask the AI teacher to switch examples, metaphors, and break it down even simpler.", fontSize = 12.sp, color = Color.LightGray)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = { viewModel.requestSimplerExplanation(lesson.topicTitle) },
                            enabled = !isSimplifying,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("mujhe_samajh_nahi_aaya_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (isSimplifying) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Preparing Fresh Analogy...")
                            } else {
                                Icon(Icons.Default.Psychology, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Mujhe Samajh Nahi Aaya — Explain Differently", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }

                        // Display simpler explanation if generated
                        if (!simplifiedExplanation.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFF78350F).copy(alpha = 0.3f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, QuestGold),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("🎯 Simpler Alternative Explanation:", fontWeight = FontWeight.Bold, color = QuestGold, fontSize = 13.sp)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = simplifiedExplanation!!,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        lineHeight = 20.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // 7. Checkpoint Question (Rule 6: Ask one short question to check understanding)
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate900),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.QuestionMark, contentDescription = null, tint = QuestCyan, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("6. Quick Understanding Checkpoint", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = QuestCyan)
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = lesson.checkpointQuestion,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        lesson.checkpointOptions.forEachIndexed { optIndex, optionText ->
                            val isSelected = (selectedOption == optIndex)
                            val isCorrectChoice = (optIndex == lesson.checkpointCorrectIndex)

                            val borderColor = when {
                                selectedOption == null -> Slate800
                                isCorrectChoice -> QuestEmerald
                                isSelected -> Color.Red
                                else -> Slate800
                            }

                            val bgColor = when {
                                selectedOption == null -> Slate800
                                isCorrectChoice -> Color(0xFF065F46)
                                isSelected -> Color(0xFF7F1D1D)
                                else -> Slate800
                            }

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = bgColor,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .border(1.dp, borderColor, RoundedCornerShape(10.dp))
                                    .clickable(enabled = selectedOption == null) {
                                        viewModel.answerCheckpoint(optIndex)
                                    }
                                    .testTag("checkpoint_option_$optIndex")
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${('A' + optIndex)}. ",
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.White else QuestCyan,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = optionText,
                                        color = Color.White,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }

                        // Explanation after answering
                        if (selectedOption != null) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isCorrect == true) Color(0xFF065F46) else Color(0xFF7F1D1D),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = if (isCorrect == true) "🎉 Correct! Well done." else "⚠️ Incorrect! Review the reason below.",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = lesson.checkpointExplanation,
                                        fontSize = 12.sp,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }

                // 8. Quiz Battle on this Topic
                Button(
                    onClick = { onStartQuiz(topicId, GameMode.QUIZ_BATTLE) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("start_topic_quiz_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = QuestIndigo),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Take Quiz Battle on This Topic", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }

                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}
