package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AnimatedRewardDialog
import com.example.ui.navigation.GameMode
import com.example.ui.navigation.Screen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ExamPrepScreen
import com.example.ui.screens.GameScreen
import com.example.ui.screens.LearnScreen
import com.example.ui.screens.SettingsApiKeyScreen
import com.example.ui.screens.SyllabusUploadScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.Slate950
import com.example.ui.viewmodel.StudyQuestViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true) {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding(),
                    color = Slate950
                ) {
                    StudyQuestApp()
                }
            }
        }
    }
}

@Composable
fun StudyQuestApp(viewModel: StudyQuestViewModel = viewModel()) {
    val activeCourse by viewModel.activeCourse.collectAsState()
    val allCourses by viewModel.allCourses.collectAsState()
    val chapters by viewModel.chapters.collectAsState()
    val topics by viewModel.topics.collectAsState()
    val weakTopics by viewModel.weakTopics.collectAsState()
    val mistakes by viewModel.mistakes.collectAsState()
    val isApiKeyConfigured by viewModel.isApiKeyConfigured.collectAsState()
    val isUploadingSyllabus by viewModel.isUploadingSyllabus.collectAsState()
    val syllabusError by viewModel.syllabusError.collectAsState()
    val activeTab by viewModel.dashboardTab.collectAsState()
    val rewardDialog by viewModel.rewardDialog.collectAsState()

    val currentScreen = viewModel.currentScreen

    BackHandler(enabled = viewModel.screenStack.size > 1) {
        viewModel.goBack()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        when (currentScreen) {
            is Screen.Welcome -> {
                WelcomeScreen(
                    viewModel = viewModel,
                    activeCourse = activeCourse,
                    onStartLearning = {
                        if (activeCourse != null) {
                            viewModel.navigateTo(Screen.Dashboard(0))
                        } else {
                            viewModel.navigateTo(Screen.SyllabusUpload)
                        }
                    },
                    onContinueLearning = {
                        viewModel.navigateTo(Screen.Dashboard(0))
                    },
                    onAiTeacherClick = {
                        viewModel.setDashboardTab(3)
                        viewModel.navigateTo(Screen.Dashboard(3))
                    }
                )
            }

            is Screen.Dashboard -> {
                DashboardScreen(
                    viewModel = viewModel,
                    activeCourse = activeCourse,
                    allCourses = allCourses,
                    chapters = chapters,
                    topics = topics,
                    weakTopics = weakTopics,
                    mistakes = mistakes,
                    activeTab = activeTab,
                    isApiKeyConfigured = isApiKeyConfigured,
                    onTabSelected = { viewModel.setDashboardTab(it) },
                    onSelectTopicToLearn = { topicId ->
                        viewModel.navigateTo(Screen.LearnLesson(topicId))
                    },
                    onStartGame = { topicId, mode ->
                        viewModel.navigateTo(Screen.QuizBattle(topicId, mode))
                    },
                    onStartExamPrep = {
                        viewModel.navigateTo(Screen.ExamPrep)
                    },
                    onOpenSyllabusUpload = {
                        viewModel.navigateTo(Screen.SyllabusUpload)
                    },
                    onOpenApiKeySettings = {
                        viewModel.navigateTo(Screen.SettingsApiKey)
                    }
                )
            }

            is Screen.SyllabusUpload -> {
                SyllabusUploadScreen(
                    viewModel = viewModel,
                    isUploading = isUploadingSyllabus,
                    errorMessage = syllabusError,
                    onBack = { viewModel.goBack() },
                    onSuccess = {
                        viewModel.setDashboardTab(0)
                        viewModel.navigateTo(Screen.Dashboard(0))
                    }
                )
            }

            is Screen.LearnLesson -> {
                val topicId = currentScreen.topicId
                LearnScreen(
                    topicId = topicId,
                    viewModel = viewModel,
                    onBack = { viewModel.goBack() },
                    onStartQuiz = { tId, mode ->
                        viewModel.navigateTo(Screen.QuizBattle(tId, mode))
                    }
                )
            }

            is Screen.QuizBattle -> {
                val topicId = currentScreen.topicId
                val mode = currentScreen.mode
                GameScreen(
                    topicId = topicId,
                    mode = mode,
                    viewModel = viewModel,
                    onBack = { viewModel.goBack() }
                )
            }

            is Screen.WrittenChallenge -> {
                val topicId = currentScreen.topicId
                GameScreen(
                    topicId = topicId,
                    mode = GameMode.WRITTEN_CHALLENGE,
                    viewModel = viewModel,
                    onBack = { viewModel.goBack() }
                )
            }

            is Screen.FlashcardRevision -> {
                val topicId = currentScreen.topicId
                GameScreen(
                    topicId = topicId,
                    mode = GameMode.QUIZ_BATTLE,
                    viewModel = viewModel,
                    onBack = { viewModel.goBack() }
                )
            }

            is Screen.ExamPrep -> {
                ExamPrepScreen(
                    activeCourse = activeCourse,
                    topics = topics,
                    viewModel = viewModel,
                    onBack = { viewModel.goBack() },
                    onStartTest = { topicId, mode ->
                        viewModel.navigateTo(Screen.QuizBattle(topicId, mode))
                    }
                )
            }

            is Screen.SettingsApiKey -> {
                SettingsApiKeyScreen(
                    viewModel = viewModel,
                    onBack = { viewModel.goBack() }
                )
            }
        }

        // Global Reward Celebration Dialog
        rewardDialog?.let { reward ->
            AnimatedRewardDialog(
                reward = reward,
                onDismiss = { viewModel.dismissRewardDialog() }
            )
        }
    }
}
