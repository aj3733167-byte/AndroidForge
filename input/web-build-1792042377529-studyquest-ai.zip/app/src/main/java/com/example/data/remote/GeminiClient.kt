package com.example.data.remote

import android.util.Log
import com.example.data.model.CourseEntity
import com.example.data.model.FlashcardItem
import com.example.data.model.GeminiContent
import com.example.data.model.GeminiGenerationConfig
import com.example.data.model.GeminiInlineData
import com.example.data.model.GeminiPart
import com.example.data.model.GeminiRequest
import com.example.data.model.LessonContent
import com.example.data.model.QuizQuestion
import com.example.data.model.TopicEntity
import com.example.data.model.WrittenEvaluation
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import org.json.JSONArray
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.UUID
import java.util.concurrent.TimeUnit

object GeminiClient {
    private const val TAG = "GeminiClient"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"
    const val DEFAULT_MODEL = "gemini-2.5-flash"

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        })
        .build()

    val apiService: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApiService::class.java)
    }

    suspend fun executePrompt(
        apiKey: String,
        prompt: String,
        systemInstruction: String? = null,
        imageBase64: String? = null,
        imageMimeType: String = "image/jpeg",
        responseJson: Boolean = false,
        model: String = DEFAULT_MODEL
    ): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(
                IllegalStateException("Gemini API key is not configured. Please add your key in the AI Studio Secrets panel or enter it in app settings.")
            )
        }

        try {
            val parts = mutableListOf<GeminiPart>()
            if (!imageBase64.isNullOrBlank()) {
                parts.add(GeminiPart(inlineData = GeminiInlineData(mimeType = imageMimeType, data = imageBase64)))
            }
            parts.add(GeminiPart(text = prompt))

            val sysContent = systemInstruction?.let {
                GeminiContent(role = "system", parts = listOf(GeminiPart(text = it)))
            }

            val config = if (responseJson) {
                GeminiGenerationConfig(responseMimeType = "application/json", temperature = 0.4f)
            } else {
                GeminiGenerationConfig(temperature = 0.7f)
            }

            val request = GeminiRequest(
                contents = listOf(GeminiContent(role = "user", parts = parts)),
                systemInstruction = sysContent,
                generationConfig = config
            )

            val response = apiService.generateContent(model = model, apiKey = apiKey, request = request)

            if (response.error != null) {
                return@withContext Result.failure(Exception("AI Error [${response.error.code}]: ${response.error.message}"))
            }

            val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (text.isNullOrBlank()) {
                Result.failure(Exception("No response received from AI model."))
            } else {
                Result.success(text)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Gemini call failed", e)
            Result.failure(e)
        }
    }

    /**
     * Parses raw JSON or markdown-wrapped JSON text into a clean string.
     */
    fun cleanJson(raw: String): String {
        var trimmed = raw.trim()
        if (trimmed.startsWith("```json")) {
            trimmed = trimmed.removePrefix("```json")
        } else if (trimmed.startsWith("```")) {
            trimmed = trimmed.removePrefix("```")
        }
        if (trimmed.endsWith("```")) {
            trimmed = trimmed.removeSuffix("```")
        }
        return trimmed.trim()
    }

    /**
     * Extract full course structure from syllabus text or image.
     */
    suspend fun extractSyllabus(
        apiKey: String,
        syllabusInput: String,
        imageBase64: String? = null
    ): Result<ParsedSyllabus> = withContext(Dispatchers.IO) {
        val prompt = """
You are an expert curriculum analyzer and master teacher for any subject, exam, and language.
Analyze the following uploaded syllabus material (text and/or image).
Extract:
1. Exact subject name (e.g. "Hindi (Course A)", "Mathematics", "Physics", "Sanskrit", "History")
2. Grade/Class (e.g. "Class 10", "College 2nd Year", "Competitive Exam")
3. Detected Language (e.g. "Hindi", "English", "Sanskrit", "Bilingual")
4. Exam Format summary (e.g. "80 Marks Theory + 20 Marks Internal. MCQs, Short Answers, Long Grammar Analysis.")
5. Chapters list. For EACH chapter, provide:
   - chapterNumber (integer)
   - title (descriptive title)
   - description (1-2 sentences on scope)
   - topics: Array of topics in this chapter. For EACH topic:
     - title (clear topic name)
     - subtopics (comma separated string of 3-5 subtopics)
     - keyDefinitions (comma separated key definitions or terms)
     - keyFormulas (comma separated key rules, formulas, or grammar points)
     - difficulty ("EASY", "MEDIUM", "HARD")

Return STRICTLY valid JSON with this schema:
{
  "subject": "...",
  "targetClass": "...",
  "language": "...",
  "examFormat": "...",
  "chapters": [
    {
      "chapterNumber": 1,
      "title": "...",
      "description": "...",
      "topics": [
        {
          "title": "...",
          "subtopics": "...",
          "keyDefinitions": "...",
          "keyFormulas": "...",
          "difficulty": "EASY"
        }
      ]
    }
  ]
}

Uploaded Syllabus Content:
$syllabusInput
""".trimIndent()

        val result = executePrompt(
            apiKey = apiKey,
            prompt = prompt,
            systemInstruction = "You extract exact syllabus topics and structures with high precision. Never invent fake chapters. Return only valid JSON.",
            imageBase64 = imageBase64,
            responseJson = true
        )

        result.mapCatching { rawText ->
            val clean = cleanJson(rawText)
            val json = JSONObject(clean)

            val subject = json.optString("subject", "General Studies")
            val targetClass = json.optString("targetClass", "Standard")
            val language = json.optString("language", "English")
            val examFormat = json.optString("examFormat", "Standard Exam")

            val chaptersList = mutableListOf<ParsedChapter>()
            val chaptersArray = json.optJSONArray("chapters") ?: JSONArray()
            for (i in 0 until chaptersArray.length()) {
                val chObj = chaptersArray.getJSONObject(i)
                val chNum = chObj.optInt("chapterNumber", i + 1)
                val chTitle = chObj.optString("title", "Chapter $chNum")
                val chDesc = chObj.optString("description", "")

                val topicsList = mutableListOf<ParsedTopic>()
                val topicsArray = chObj.optJSONArray("topics") ?: JSONArray()
                for (j in 0 until topicsArray.length()) {
                    val tObj = topicsArray.getJSONObject(j)
                    topicsList.add(
                        ParsedTopic(
                            title = tObj.optString("title", "Topic ${j + 1}"),
                            subtopics = tObj.optString("subtopics", ""),
                            keyDefinitions = tObj.optString("keyDefinitions", ""),
                            keyFormulas = tObj.optString("keyFormulas", ""),
                            difficulty = tObj.optString("difficulty", "MEDIUM")
                        )
                    )
                }

                chaptersList.add(
                    ParsedChapter(
                        chapterNumber = chNum,
                        title = chTitle,
                        description = chDesc,
                        topics = topicsList
                    )
                )
            }

            ParsedSyllabus(
                subject = subject,
                targetClass = targetClass,
                language = language,
                examFormat = examFormat,
                chapters = chaptersList
            )
        }
    }

    /**
     * Generate step-by-step interactive lesson for a topic.
     */
    suspend fun generateLesson(
        apiKey: String,
        course: CourseEntity,
        topic: TopicEntity,
        language: String, // "Hindi", "English", "Hinglish"
        style: String // "From Basics", "Detailed", "Brief"
    ): Result<LessonContent> = withContext(Dispatchers.IO) {
        val prompt = """
Teach the following topic step-by-step as an expert personal AI teacher:
Course: ${course.subject} (${course.targetClass})
Topic: ${topic.title}
Key Subtopics: ${topic.subtopics}
Rules / Formulas: ${topic.keyFormulas}
Definitions: ${topic.keyDefinitions}

Language requirement: $language
Teaching depth: $style

Follow this teaching sequence and return valid JSON:
1. introduction: Warm, friendly 2-3 sentence introduction in $language.
2. coreConcept: Deep, clear explanation of how and why it works.
3. realWorldAnalogy: A relatable everyday analogy or memory story.
4. clearExamples: Array of 2 to 3 clear, practical examples with step-by-step breakdown.
5. difficultPartsDeepDive: Explain the most confusing or trickiest part and how to avoid common mistakes.
6. formulasOrRules: Array of key formulas, grammar rules, or principles.
7. checkpointQuestion: A short check-for-understanding question.
8. checkpointOptions: Array of 4 multiple-choice options.
9. checkpointCorrectIndex: Integer (0-3) indicating correct answer.
10. checkpointExplanation: Clear explanation of why the correct option is right.

JSON format:
{
  "introduction": "...",
  "coreConcept": "...",
  "realWorldAnalogy": "...",
  "clearExamples": ["...", "..."],
  "difficultPartsDeepDive": "...",
  "formulasOrRules": ["...", "..."],
  "checkpointQuestion": "...",
  "checkpointOptions": ["...", "...", "...", "..."],
  "checkpointCorrectIndex": 0,
  "checkpointExplanation": "..."
}
""".trimIndent()

        val result = executePrompt(
            apiKey = apiKey,
            prompt = prompt,
            systemInstruction = "You are a warm, world-class personal teacher. You explain complex ideas with crystal clarity in the user's preferred language. Never produce generic responses. Return strictly valid JSON.",
            responseJson = true
        )

        result.mapCatching { rawText ->
            val clean = cleanJson(rawText)
            val json = JSONObject(clean)

            val examples = mutableListOf<String>()
            val exArr = json.optJSONArray("clearExamples") ?: JSONArray()
            for (i in 0 until exArr.length()) examples.add(exArr.getString(i))

            val rules = mutableListOf<String>()
            val rArr = json.optJSONArray("formulasOrRules") ?: JSONArray()
            for (i in 0 until rArr.length()) rules.add(rArr.getString(i))

            val options = mutableListOf<String>()
            val opArr = json.optJSONArray("checkpointOptions") ?: JSONArray()
            for (i in 0 until opArr.length()) options.add(opArr.getString(i))

            LessonContent(
                topicTitle = topic.title,
                introduction = json.optString("introduction", "Welcome to this lesson on ${topic.title}."),
                coreConcept = json.optString("coreConcept", "Here is the key idea behind ${topic.title}."),
                realWorldAnalogy = json.optString("realWorldAnalogy", "Think of this like an everyday system."),
                clearExamples = if (examples.isNotEmpty()) examples else listOf("Example 1: Basic application."),
                difficultPartsDeepDive = json.optString("difficultPartsDeepDive", "Watch out for common edge cases."),
                formulasOrRules = if (rules.isNotEmpty()) rules else listOf("Rule: Apply fundamental principle."),
                checkpointQuestion = json.optString("checkpointQuestion", "What is the core principle of ${topic.title}?"),
                checkpointOptions = if (options.size == 4) options else listOf("Option A", "Option B", "Option C", "Option D"),
                checkpointCorrectIndex = json.optInt("checkpointCorrectIndex", 0),
                checkpointExplanation = json.optString("checkpointExplanation", "This is the correct principle.")
            )
        }
    }

    /**
     * When student says "Mujhe samajh nahi aaya" - AI gives a totally different analogy, simpler language, step-by-step breakdown.
     */
    suspend fun explainSimplerAlternative(
        apiKey: String,
        course: CourseEntity,
        topicTitle: String,
        previousExplanation: String,
        language: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val prompt = """
The student did NOT understand the previous explanation of "$topicTitle" in ${course.subject}.
They said: "Mujhe samajh nahi aaya! Please explain differently."

Do NOT repeat the previous explanation word-for-word!
Use:
1. A completely fresh, everyday real-world analogy.
2. Ultra-simple language in $language.
3. A tiny bite-sized 3-step breakdown.
4. One simple relatable example with everyday items (e.g. cricket, food, money, mobile apps).
5. A reassuring encouraging tone.

Previous explanation that was confusing:
$previousExplanation
""".trimIndent()

        executePrompt(
            apiKey = apiKey,
            prompt = prompt,
            systemInstruction = "You are a patient, encouraging tutor. When a student is stuck, you pivot to visual analogies, simple everyday metaphors, and zero jargon."
        )
    }

    /**
     * Generate interactive quiz questions for Quiz Battle, Boss Battle, Survival, Rapid Fire.
     */
    suspend fun generateQuizQuestions(
        apiKey: String,
        course: CourseEntity,
        topic: TopicEntity,
        count: Int = 4,
        difficulty: String = "MEDIUM",
        modeName: String = "Quiz Battle"
    ): Result<List<QuizQuestion>> = withContext(Dispatchers.IO) {
        val prompt = """
Generate $count high-quality multiple choice questions for:
Subject: ${course.subject} (${course.targetClass})
Topic: ${topic.title}
Subtopics: ${topic.subtopics}
Rules/Definitions: ${topic.keyDefinitions} | ${topic.keyFormulas}
Game Mode: $modeName
Target Difficulty: $difficulty
Language: ${course.language}

For EVERY question, provide:
- question: The question text.
- options: Exactly 4 distinct options [A, B, C, D].
- correctIndex: 0, 1, 2, or 3.
- explanation: Detailed explanation of why the correct option is right.
- whyWrong: Object with keys "0", "1", "2", "3" briefly explaining why each wrong option is wrong.
- memoryTrick: A quick mnemonic, formula tip, or memory rule.

Return STRICTLY JSON array:
[
  {
    "question": "...",
    "options": ["A", "B", "C", "D"],
    "correctIndex": 0,
    "explanation": "...",
    "whyWrong": {
      "1": "Why option B is wrong...",
      "2": "Why option C is wrong...",
      "3": "Why option D is wrong..."
    },
    "memoryTrick": "..."
  }
]
""".trimIndent()

        val result = executePrompt(
            apiKey = apiKey,
            prompt = prompt,
            systemInstruction = "You are an expert exam question creator. Generate rigorous, syllabus-aligned multiple choice questions with comprehensive explanations. Return only valid JSON.",
            responseJson = true
        )

        result.mapCatching { rawText ->
            val clean = cleanJson(rawText)
            val array = JSONArray(clean)
            val questions = mutableListOf<QuizQuestion>()

            for (i in 0 until array.length()) {
                val qObj = array.getJSONObject(i)
                val qText = qObj.optString("question", "Question ${i + 1}")
                val optArr = qObj.optJSONArray("options") ?: JSONArray()
                val options = mutableListOf<String>()
                for (j in 0 until optArr.length()) {
                    options.add(optArr.getString(j))
                }
                while (options.size < 4) {
                    options.add("Option ${options.size + 1}")
                }

                val correctIdx = qObj.optInt("correctIndex", 0).coerceIn(0, 3)
                val exp = qObj.optString("explanation", "Correct choice.")
                val trick = qObj.optString("memoryTrick", "Remember the core rule.")

                val whyWrongMap = mutableMapOf<Int, String>()
                val whyWrongObj = qObj.optJSONObject("whyWrong")
                if (whyWrongObj != null) {
                    val keys = whyWrongObj.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        val kInt = key.toIntOrNull()
                        if (kInt != null) {
                            whyWrongMap[kInt] = whyWrongObj.optString(key)
                        }
                    }
                }

                questions.add(
                    QuizQuestion(
                        id = UUID.randomUUID().toString(),
                        topicTitle = topic.title,
                        question = qText,
                        options = options,
                        correctIndex = correctIdx,
                        explanation = exp,
                        whyWrongMap = whyWrongMap,
                        memoryTrick = trick,
                        difficulty = difficulty
                    )
                )
            }
            questions
        }
    }

    /**
     * Smart Teaching for Wrong Answers (Rule 8):
     * 1. Shows user's answer vs correct answer
     * 2. Why it was wrong
     * 3. Underlying concept in easy language
     * 4. Two relevant examples
     * 5. Memory trick
     * 6. Simpler follow-up question
     */
    suspend fun teachWrongAnswer(
        apiKey: String,
        course: CourseEntity,
        topicTitle: String,
        question: String,
        userAnswer: String,
        correctAnswer: String
    ): Result<SmartWrongAnswerFeedback> = withContext(Dispatchers.IO) {
        val prompt = """
The student answered a question incorrectly in ${course.subject} on topic "$topicTitle".
Question: $question
Student's Chosen Answer: $userAnswer
Correct Answer: $correctAnswer
Course Language: ${course.language}

Provide a comprehensive teaching feedback according to Rule 8:
1. whyUserWasWrong: Explain the exact misconception or reason behind student's choice.
2. conceptExplanation: Teach the core concept clearly and simply.
3. practicalExamples: Array of 2 clear everyday examples illustrating the concept.
4. memoryTrick: A catchy mnemonic, rhyme, or quick rule to never forget.
5. followUpQuestion: A simpler follow-up question to test if they understood now.
6. followUpOptions: Exactly 4 options for the follow-up question.
7. followUpCorrectIndex: Integer (0-3).
8. followUpExplanation: Brief explanation of the follow-up answer.

Return STRICTLY JSON:
{
  "whyUserWasWrong": "...",
  "conceptExplanation": "...",
  "practicalExamples": ["...", "..."],
  "memoryTrick": "...",
  "followUpQuestion": "...",
  "followUpOptions": ["...", "...", "...", "..."],
  "followUpCorrectIndex": 0,
  "followUpExplanation": "..."
}
""".trimIndent()

        val result = executePrompt(
            apiKey = apiKey,
            prompt = prompt,
            systemInstruction = "You are a master teacher who turns every mistake into an unforgettable learning moment. Return only JSON.",
            responseJson = true
        )

        result.mapCatching { rawText ->
            val clean = cleanJson(rawText)
            val json = JSONObject(clean)

            val examples = mutableListOf<String>()
            val exArr = json.optJSONArray("practicalExamples") ?: JSONArray()
            for (i in 0 until exArr.length()) examples.add(exArr.getString(i))

            val followUpOptions = mutableListOf<String>()
            val foArr = json.optJSONArray("followUpOptions") ?: JSONArray()
            for (i in 0 until foArr.length()) followUpOptions.add(foArr.getString(i))

            SmartWrongAnswerFeedback(
                whyUserWasWrong = json.optString("whyUserWasWrong", "The selected option conflicts with the key rule."),
                conceptExplanation = json.optString("conceptExplanation", "The core concept states that..."),
                practicalExamples = if (examples.isNotEmpty()) examples else listOf("Example A", "Example B"),
                memoryTrick = json.optString("memoryTrick", "Remember the key formula."),
                followUpQuestion = json.optString("followUpQuestion", "Now let's check: which statement matches the correct rule?"),
                followUpOptions = if (followUpOptions.size == 4) followUpOptions else listOf("Option 1", "Option 2", "Option 3", "Option 4"),
                followUpCorrectIndex = json.optInt("followUpCorrectIndex", 0),
                followUpExplanation = json.optString("followUpExplanation", "Great job applying the concept!")
            )
        }
    }

    /**
     * Evaluate written response with partial credit, model answer, and rubrics.
     */
    suspend fun evaluateWrittenAnswer(
        apiKey: String,
        course: CourseEntity,
        topicTitle: String,
        question: String,
        studentAnswer: String,
        maxScore: Int = 10
    ): Result<WrittenEvaluation> = withContext(Dispatchers.IO) {
        val prompt = """
You are an official examiner evaluating a student's written response:
Subject: ${course.subject} (${course.targetClass})
Topic: $topicTitle
Question: $question
Max Marks: $maxScore
Student's Answer:
"$studentAnswer"

Evaluate strictly and constructively:
1. score: Integer out of $maxScore based on correctness, depth, keywords, and clarity.
2. feedback: Detailed constructive review.
3. modelAnswer: The ideal full-marks answer.
4. strengths: Array of strong points in student's answer.
5. areasToImprove: Array of missing definitions, formulas, facts, or formatting tips.

Return JSON:
{
  "score": 8,
  "maxScore": $maxScore,
  "feedback": "...",
  "modelAnswer": "...",
  "strengths": ["...", "..."],
  "areasToImprove": ["...", "..."]
}
""".trimIndent()

        val result = executePrompt(
            apiKey = apiKey,
            prompt = prompt,
            systemInstruction = "You are an experienced examination evaluator. Provide realistic marks and actionable feedback. Return only JSON.",
            responseJson = true
        )

        result.mapCatching { rawText ->
            val clean = cleanJson(rawText)
            val json = JSONObject(clean)

            val strList = mutableListOf<String>()
            val strArr = json.optJSONArray("strengths") ?: JSONArray()
            for (i in 0 until strArr.length()) strList.add(strArr.getString(i))

            val impList = mutableListOf<String>()
            val impArr = json.optJSONArray("areasToImprove") ?: JSONArray()
            for (i in 0 until impArr.length()) impList.add(impArr.getString(i))

            WrittenEvaluation(
                score = json.optInt("score", (maxScore * 0.7).toInt()),
                maxScore = maxScore,
                feedback = json.optString("feedback", "Good effort. Review key definitions for full marks."),
                modelAnswer = json.optString("modelAnswer", "Standard model answer."),
                strengths = if (strList.isNotEmpty()) strList else listOf("Addressed the main question"),
                areasToImprove = if (impList.isNotEmpty()) impList else listOf("Include specific formulas or examples")
            )
        }
    }

    /**
     * Conversational AI Tutor Chat (Rule 10).
     */
    suspend fun chatWithTutor(
        apiKey: String,
        course: CourseEntity,
        chatHistory: List<com.example.data.model.ChatMessageEntity>,
        userMessage: String,
        weakTopics: List<TopicEntity>
    ): Result<String> = withContext(Dispatchers.IO) {
        val weakTopicsStr = if (weakTopics.isNotEmpty()) {
            "Student's current weak topics in this course: " + weakTopics.joinToString { it.title }
        } else {
            "Student has not flagged any weak topics yet."
        }

        val historyFormatted = chatHistory.takeLast(10).joinToString("\n") {
            "${it.sender}: ${it.text}"
        }

        val prompt = """
You are the student's personal AI Teacher and Study Coach for:
Course: ${course.subject} (${course.targetClass})
Syllabus: ${course.syllabusText.take(500)}
$weakTopicsStr

Conversation History:
$historyFormatted

Student's Latest Message:
"$userMessage"

Guidelines:
1. Answer directly and warmly as their dedicated tutor.
2. Speak in the student's chosen language or the language they addressed you in (Hindi, English, or Hinglish).
3. If they ask about exam questions, explain the concepts and ask a practice question.
4. If they ask "Yeh topic dobara samjhao", provide a fresh example or analogy.
5. If they ask something outside the course syllabus, politely answer using general knowledge while clearly indicating it is outside their syllabus.
6. If the question is ambiguous, ask a clarifying question.
7. Keep responses engaging, supportive, and pedagogical.
""".trimIndent()

        executePrompt(
            apiKey = apiKey,
            prompt = prompt,
            systemInstruction = "You are StudyQuest's personal AI Teacher. You inspire curiosity, explain intuitively, and guide the student towards syllabus mastery."
        )
    }

    /**
     * Generate flashcards for revision.
     */
    suspend fun generateFlashcards(
        apiKey: String,
        course: CourseEntity,
        topicTitle: String
    ): Result<List<FlashcardItem>> = withContext(Dispatchers.IO) {
        val prompt = """
Generate 6 concise, high-yield flashcards for revision of "$topicTitle" in ${course.subject}:
Include:
- Definitions
- Key formulas or grammar rules
- Important dates or concepts
- Common pitfalls

Return JSON array:
[
  {
    "frontPrompt": "...",
    "backAnswer": "...",
    "category": "Definition | Formula | Concept | Rule"
  }
]
""".trimIndent()

        val result = executePrompt(
            apiKey = apiKey,
            prompt = prompt,
            systemInstruction = "You create high-yield study flashcards for fast recall. Return only valid JSON.",
            responseJson = true
        )

        result.mapCatching { rawText ->
            val clean = cleanJson(rawText)
            val array = JSONArray(clean)
            val cards = mutableListOf<FlashcardItem>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                cards.add(
                    FlashcardItem(
                        id = UUID.randomUUID().toString(),
                        frontPrompt = obj.optString("frontPrompt", "Front"),
                        backAnswer = obj.optString("backAnswer", "Back"),
                        category = obj.optString("category", "Concept")
                    )
                )
            }
            cards
        }
    }
}

data class ParsedSyllabus(
    val subject: String,
    val targetClass: String,
    val language: String,
    val examFormat: String,
    val chapters: List<ParsedChapter>
)

data class ParsedChapter(
    val chapterNumber: Int,
    val title: String,
    val description: String,
    val topics: List<ParsedTopic>
)

data class ParsedTopic(
    val title: String,
    val subtopics: String,
    val keyDefinitions: String,
    val keyFormulas: String,
    val difficulty: String
)

data class SmartWrongAnswerFeedback(
    val whyUserWasWrong: String,
    val conceptExplanation: String,
    val practicalExamples: List<String>,
    val memoryTrick: String,
    val followUpQuestion: String,
    val followUpOptions: List<String>,
    val followUpCorrectIndex: Int,
    val followUpExplanation: String
)
