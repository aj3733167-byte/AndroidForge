package com.example.ui.viewmodel

import android.app.Application
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.ChapterEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.CourseEntity
import com.example.data.model.FlashcardItem
import com.example.data.model.LessonContent
import com.example.data.model.MistakeEntity
import com.example.data.model.QuizQuestion
import com.example.data.model.TopicEntity
import com.example.data.model.UserProfileEntity
import com.example.data.model.WrittenEvaluation
import com.example.data.remote.SmartWrongAnswerFeedback
import com.example.data.repository.StudyQuestRepository
import com.example.ui.navigation.GameMode
import com.example.ui.navigation.Screen
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class RewardData(
    val title: String,
    val xpEarned: Int,
    val coinsEarned: Int,
    val message: String
)

class StudyQuestViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val repository = StudyQuestRepository(db.studyQuestDao(), application)

    // Navigation BackStack
    val screenStack = mutableStateListOf<Screen>(Screen.Welcome)
    val currentScreen: Screen
        get() = screenStack.lastOrNull() ?: Screen.Welcome

    // Dashboard Active Tab: 0=Learn, 1=Game, 2=Revision, 3=AI Teacher
    private val _dashboardTab = MutableStateFlow(0)
    val dashboardTab: StateFlow<Int> = _dashboardTab.asStateFlow()

    // Active Course
    val allCourses: StateFlow<List<CourseEntity>> = repository.allCourses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userProfile: StateFlow<UserProfileEntity?> = repository.userProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _selectedCourseId = MutableStateFlow<String?>(null)
    val selectedCourseId: StateFlow<String?> = _selectedCourseId.asStateFlow()

    val activeCourse: StateFlow<CourseEntity?> = combine(allCourses, _selectedCourseId, userProfile) { courses, selectedId, profile ->
        when {
            selectedId != null -> courses.find { it.id == selectedId }
            !profile?.activeCourseId.isNullOrBlank() -> courses.find { it.id == profile?.activeCourseId }
            courses.isNotEmpty() -> courses.first()
            else -> null
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Active Course Child Flows
    private val _chapters = MutableStateFlow<List<ChapterEntity>>(emptyList())
    val chapters: StateFlow<List<ChapterEntity>> = _chapters.asStateFlow()

    private val _topics = MutableStateFlow<List<TopicEntity>>(emptyList())
    val topics: StateFlow<List<TopicEntity>> = _topics.asStateFlow()

    private val _weakTopics = MutableStateFlow<List<TopicEntity>>(emptyList())
    val weakTopics: StateFlow<List<TopicEntity>> = _weakTopics.asStateFlow()

    private val _mistakes = MutableStateFlow<List<MistakeEntity>>(emptyList())
    val mistakes: StateFlow<List<MistakeEntity>> = _mistakes.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessageEntity>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessageEntity>> = _chatMessages.asStateFlow()

    // API Key State
    private val _isApiKeyConfigured = MutableStateFlow(false)
    val isApiKeyConfigured: StateFlow<Boolean> = _isApiKeyConfigured.asStateFlow()

    // Syllabus Upload State
    private val _isUploadingSyllabus = MutableStateFlow(false)
    val isUploadingSyllabus: StateFlow<Boolean> = _isUploadingSyllabus.asStateFlow()

    private val _syllabusError = MutableStateFlow<String?>(null)
    val syllabusError: StateFlow<String?> = _syllabusError.asStateFlow()

    // Learn Screen State
    private val _activeLesson = MutableStateFlow<LessonContent?>(null)
    val activeLesson: StateFlow<LessonContent?> = _activeLesson.asStateFlow()

    private val _isLessonLoading = MutableStateFlow(false)
    val isLessonLoading: StateFlow<Boolean> = _isLessonLoading.asStateFlow()

    private val _simplifiedExplanation = MutableStateFlow<String?>(null)
    val simplifiedExplanation: StateFlow<String?> = _simplifiedExplanation.asStateFlow()

    private val _isSimplifying = MutableStateFlow(false)
    val isSimplifying: StateFlow<Boolean> = _isSimplifying.asStateFlow()

    private val _lessonLanguage = MutableStateFlow("Hinglish")
    val lessonLanguage: StateFlow<String> = _lessonLanguage.asStateFlow()

    private val _lessonStyle = MutableStateFlow("From Basics")
    val lessonStyle: StateFlow<String> = _lessonStyle.asStateFlow()

    private val _checkpointAnswerSelected = MutableStateFlow<Int?>(null)
    val checkpointAnswerSelected: StateFlow<Int?> = _checkpointAnswerSelected.asStateFlow()

    private val _checkpointAnswerCorrect = MutableStateFlow<Boolean?>(null)
    val checkpointAnswerCorrect: StateFlow<Boolean?> = _checkpointAnswerCorrect.asStateFlow()

    // Quiz & Game State
    private val _gameMode = MutableStateFlow(GameMode.QUIZ_BATTLE)
    val gameMode: StateFlow<GameMode> = _gameMode.asStateFlow()

    private val _quizQuestions = MutableStateFlow<List<QuizQuestion>>(emptyList())
    val quizQuestions: StateFlow<List<QuizQuestion>> = _quizQuestions.asStateFlow()

    private val _currentQuestionIndex = MutableStateFlow(0)
    val currentQuestionIndex: StateFlow<Int> = _currentQuestionIndex.asStateFlow()

    private val _selectedQuizOption = MutableStateFlow<Int?>(null)
    val selectedQuizOption: StateFlow<Int?> = _selectedQuizOption.asStateFlow()

    private val _isQuizAnswerSubmitted = MutableStateFlow(false)
    val isQuizAnswerSubmitted: StateFlow<Boolean> = _isQuizAnswerSubmitted.asStateFlow()

    private val _isQuizAnswerCorrect = MutableStateFlow<Boolean?>(null)
    val isQuizAnswerCorrect: StateFlow<Boolean?> = _isQuizAnswerCorrect.asStateFlow()

    private val _smartWrongFeedback = MutableStateFlow<SmartWrongAnswerFeedback?>(null)
    val smartWrongFeedback: StateFlow<SmartWrongAnswerFeedback?> = _smartWrongFeedback.asStateFlow()

    private val _followUpAnswerSelected = MutableStateFlow<Int?>(null)
    val followUpAnswerSelected: StateFlow<Int?> = _followUpAnswerSelected.asStateFlow()

    private val _followUpAnswerCorrect = MutableStateFlow<Boolean?>(null)
    val followUpAnswerCorrect: StateFlow<Boolean?> = _followUpAnswerCorrect.asStateFlow()

    private val _survivalHearts = MutableStateFlow(3)
    val survivalHearts: StateFlow<Int> = _survivalHearts.asStateFlow()

    private val _rapidFireSeconds = MutableStateFlow(15)
    val rapidFireSeconds: StateFlow<Int> = _rapidFireSeconds.asStateFlow()

    private val _quizXpEarned = MutableStateFlow(0)
    val quizXpEarned: StateFlow<Int> = _quizXpEarned.asStateFlow()

    private val _quizCoinsEarned = MutableStateFlow(0)
    val quizCoinsEarned: StateFlow<Int> = _quizCoinsEarned.asStateFlow()

    private val _quizStreak = MutableStateFlow(0)
    val quizStreak: StateFlow<Int> = _quizStreak.asStateFlow()

    private val _isQuizLoading = MutableStateFlow(false)
    val isQuizLoading: StateFlow<Boolean> = _isQuizLoading.asStateFlow()

    private val _isQuizCompleted = MutableStateFlow(false)
    val isQuizCompleted: StateFlow<Boolean> = _isQuizCompleted.asStateFlow()

    // Boss Battle HP
    private val _bossHp = MutableStateFlow(100)
    val bossHp: StateFlow<Int> = _bossHp.asStateFlow()

    private val _playerHp = MutableStateFlow(100)
    val playerHp: StateFlow<Int> = _playerHp.asStateFlow()

    // Written Challenge State
    private val _writtenEvaluation = MutableStateFlow<WrittenEvaluation?>(null)
    val writtenEvaluation: StateFlow<WrittenEvaluation?> = _writtenEvaluation.asStateFlow()

    private val _isEvaluatingWritten = MutableStateFlow(false)
    val isEvaluatingWritten: StateFlow<Boolean> = _isEvaluatingWritten.asStateFlow()

    // Flashcards State
    private val _flashcards = MutableStateFlow<List<FlashcardItem>>(emptyList())
    val flashcards: StateFlow<List<FlashcardItem>> = _flashcards.asStateFlow()

    private val _currentFlashcardIndex = MutableStateFlow(0)
    val currentFlashcardIndex: StateFlow<Int> = _currentFlashcardIndex.asStateFlow()

    private val _isCardFlipped = MutableStateFlow(false)
    val isCardFlipped: StateFlow<Boolean> = _isCardFlipped.asStateFlow()

    // AI Tutor Chat State
    private val _chatInput = MutableStateFlow("")
    val chatInput: StateFlow<String> = _chatInput.asStateFlow()

    private val _isTutorTyping = MutableStateFlow(false)
    val isTutorTyping: StateFlow<Boolean> = _isTutorTyping.asStateFlow()

    // Reward Dialog
    private val _rewardDialog = MutableStateFlow<RewardData?>(null)
    val rewardDialog: StateFlow<RewardData?> = _rewardDialog.asStateFlow()

    private var rapidFireJob: Job? = null

    init {
        checkApiKey()
        viewModelScope.launch {
            repository.initializeStarterDataIfEmpty()
        }
        observeActiveCourseData()
    }

    fun checkApiKey() {
        _isApiKeyConfigured.value = repository.isApiKeyConfigured()
    }

    fun saveCustomApiKey(key: String) {
        repository.saveCustomApiKey(key)
        checkApiKey()
    }

    private fun observeActiveCourseData() {
        viewModelScope.launch {
            activeCourse.collect { course ->
                if (course != null) {
                    launch { repository.getChapters(course.id).collect { _chapters.value = it } }
                    launch { repository.getTopics(course.id).collect { _topics.value = it } }
                    launch { repository.getWeakTopics(course.id).collect { _weakTopics.value = it } }
                    launch { repository.getMistakes(course.id).collect { _mistakes.value = it } }
                    launch { repository.getChatMessages(course.id).collect { _chatMessages.value = it } }
                }
            }
        }
    }

    // Navigation
    fun navigateTo(screen: Screen) {
        screenStack.add(screen)
    }

    fun goBack(): Boolean {
        if (screenStack.size > 1) {
            screenStack.removeAt(screenStack.lastIndex)
            return true
        }
        return false
    }

    fun setDashboardTab(tab: Int) {
        _dashboardTab.value = tab
    }

    fun switchCourse(courseId: String) {
        _selectedCourseId.value = courseId
        viewModelScope.launch {
            repository.setActiveCourse(courseId)
        }
    }

    // Syllabus Upload
    fun uploadSyllabus(
        title: String,
        text: String,
        imageBase64: String? = null,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            _isUploadingSyllabus.value = true
            _syllabusError.value = null
            val result = repository.createCourseFromSyllabus(title, text, imageBase64)
            _isUploadingSyllabus.value = false
            result.onSuccess { course ->
                _selectedCourseId.value = course.id
                onSuccess()
            }.onFailure { err ->
                _syllabusError.value = err.message ?: "Failed to process syllabus"
            }
        }
    }

    // Lesson Teaching Flow
    fun loadLesson(topicId: String) {
        val course = activeCourse.value ?: return
        viewModelScope.launch {
            val topic = repository.getTopic(topicId) ?: return@launch
            _isLessonLoading.value = true
            _activeLesson.value = null
            _simplifiedExplanation.value = null
            _checkpointAnswerSelected.value = null
            _checkpointAnswerCorrect.value = null

            val result = repository.fetchLesson(
                course = course,
                topic = topic,
                language = _lessonLanguage.value,
                style = _lessonStyle.value
            )
            _isLessonLoading.value = false
            result.onSuccess { lesson ->
                _activeLesson.value = lesson
            }
        }
    }

    fun requestSimplerExplanation(topicTitle: String) {
        val course = activeCourse.value ?: return
        val currentExplanation = _activeLesson.value?.coreConcept ?: ""
        viewModelScope.launch {
            _isSimplifying.value = true
            val result = repository.getSimplerExplanation(
                course = course,
                topicTitle = topicTitle,
                previousText = currentExplanation,
                language = _lessonLanguage.value
            )
            _isSimplifying.value = false
            result.onSuccess { simplerText ->
                _simplifiedExplanation.value = simplerText
            }
        }
    }

    fun setLessonLanguage(lang: String, topicId: String) {
        _lessonLanguage.value = lang
        loadLesson(topicId)
    }

    fun setLessonStyle(style: String, topicId: String) {
        _lessonStyle.value = style
        loadLesson(topicId)
    }

    fun answerCheckpoint(index: Int) {
        val lesson = _activeLesson.value ?: return
        _checkpointAnswerSelected.value = index
        val isCorrect = (index == lesson.checkpointCorrectIndex)
        _checkpointAnswerCorrect.value = isCorrect
        if (isCorrect) {
            grantReward("Checkpoint Mastered!", 30, 10, "Great understanding of the fundamentals!")
        }
    }

    // Quiz & Games Flow
    fun startQuiz(topicId: String, mode: GameMode) {
        val course = activeCourse.value ?: return
        _gameMode.value = mode
        _currentQuestionIndex.value = 0
        _selectedQuizOption.value = null
        _isQuizAnswerSubmitted.value = false
        _isQuizAnswerCorrect.value = null
        _smartWrongFeedback.value = null
        _followUpAnswerSelected.value = null
        _followUpAnswerCorrect.value = null
        _quizXpEarned.value = 0
        _quizCoinsEarned.value = 0
        _quizStreak.value = 0
        _survivalHearts.value = 3
        _bossHp.value = 100
        _playerHp.value = 100
        _isQuizCompleted.value = false

        viewModelScope.launch {
            val topic = repository.getTopic(topicId) ?: return@launch
            _isQuizLoading.value = true
            val count = when (mode) {
                GameMode.RAPID_FIRE -> 5
                GameMode.BOSS_BATTLE -> 4
                GameMode.SURVIVAL -> 6
                else -> 4
            }
            val result = repository.fetchQuizQuestions(
                course = course,
                topic = topic,
                count = count,
                difficulty = topic.difficulty,
                modeName = mode.displayName
            )
            _isQuizLoading.value = false
            result.onSuccess { questions ->
                _quizQuestions.value = questions
                if (mode == GameMode.RAPID_FIRE) {
                    startRapidFireCountdown()
                }
            }
        }
    }

    private fun startRapidFireCountdown() {
        rapidFireJob?.cancel()
        _rapidFireSeconds.value = 15
        rapidFireJob = viewModelScope.launch {
            while (_rapidFireSeconds.value > 0 && !_isQuizAnswerSubmitted.value && !_isQuizCompleted.value) {
                delay(1000)
                _rapidFireSeconds.value -= 1
            }
            if (_rapidFireSeconds.value <= 0 && !_isQuizAnswerSubmitted.value) {
                submitQuizAnswer(-1) // timed out
            }
        }
    }

    fun submitQuizAnswer(selectedIndex: Int) {
        rapidFireJob?.cancel()
        val questions = _quizQuestions.value
        val currentIndex = _currentQuestionIndex.value
        if (currentIndex >= questions.size) return
        val currentQ = questions[currentIndex]

        _selectedQuizOption.value = selectedIndex
        _isQuizAnswerSubmitted.value = true

        val isRight = (selectedIndex == currentQ.correctIndex)
        _isQuizAnswerCorrect.value = isRight

        val course = activeCourse.value ?: return

        if (isRight) {
            val bonusStreak = _quizStreak.value + 1
            _quizStreak.value = bonusStreak
            val xpGain = 20 + (bonusStreak * 5)
            val coinGain = 10 + (bonusStreak * 2)
            _quizXpEarned.value += xpGain
            _quizCoinsEarned.value += coinGain

            if (_gameMode.value == GameMode.BOSS_BATTLE) {
                _bossHp.value = (_bossHp.value - 25).coerceAtLeast(0)
            }

            viewModelScope.launch {
                repository.rewardXpAndCoins(course.id, xpGain, coinGain)
            }
        } else {
            _quizStreak.value = 0
            val chosenText = if (selectedIndex in currentQ.options.indices) currentQ.options[selectedIndex] else "Time Out / No Answer"
            val correctText = currentQ.options[currentQ.correctIndex]

            if (_gameMode.value == GameMode.SURVIVAL) {
                _survivalHearts.value = (_survivalHearts.value - 1).coerceAtLeast(0)
            } else if (_gameMode.value == GameMode.BOSS_BATTLE) {
                _playerHp.value = (_playerHp.value - 25).coerceAtLeast(0)
            }

            // Trigger Smart Wrong-Answer Teaching (Rule 8)
            viewModelScope.launch {
                val feedbackResult = repository.teachMistakeWithAi(
                    course = course,
                    topicTitle = currentQ.topicTitle,
                    question = currentQ.question,
                    userAnswer = chosenText,
                    correctAnswer = correctText
                )
                feedbackResult.onSuccess { fb ->
                    _smartWrongFeedback.value = fb
                    // Automatically log into revision room database
                    repository.logMistake(
                        courseId = course.id,
                        topicId = "quiz_topic",
                        topicTitle = currentQ.topicTitle,
                        question = currentQ.question,
                        userAnswer = chosenText,
                        correctAnswer = correctText,
                        whyWrong = fb.whyUserWasWrong,
                        conceptExplanation = fb.conceptExplanation,
                        memoryTrick = fb.memoryTrick
                    )
                }
            }
        }
    }

    fun answerSmartFollowUp(index: Int) {
        val fb = _smartWrongFeedback.value ?: return
        _followUpAnswerSelected.value = index
        val isCorrect = (index == fb.followUpCorrectIndex)
        _followUpAnswerCorrect.value = isCorrect
        if (isCorrect) {
            grantReward("Concept Unlocked!", 15, 5, "You grasped the core concept after revision!")
        }
    }

    fun nextQuestion(topicId: String) {
        val questions = _quizQuestions.value
        val nextIdx = _currentQuestionIndex.value + 1

        if (_gameMode.value == GameMode.SURVIVAL && _survivalHearts.value <= 0) {
            _isQuizCompleted.value = true
            return
        }

        if (nextIdx < questions.size) {
            _currentQuestionIndex.value = nextIdx
            _selectedQuizOption.value = null
            _isQuizAnswerSubmitted.value = false
            _isQuizAnswerCorrect.value = null
            _smartWrongFeedback.value = null
            _followUpAnswerSelected.value = null
            _followUpAnswerCorrect.value = null
            if (_gameMode.value == GameMode.RAPID_FIRE) {
                startRapidFireCountdown()
            }
        } else {
            _isQuizCompleted.value = true
            val course = activeCourse.value
            if (course != null) {
                viewModelScope.launch {
                    repository.markTopicCompleted(topicId, course.id)
                }
            }
            grantReward(
                title = "Quest Completed!",
                xp = _quizXpEarned.value + 50,
                coins = _quizCoinsEarned.value + 25,
                msg = "Topic mastered! Progress saved."
            )
        }
    }

    // Written Challenge Flow
    fun submitWrittenAnswer(topicTitle: String, question: String, answer: String) {
        val course = activeCourse.value ?: return
        viewModelScope.launch {
            _isEvaluatingWritten.value = true
            _writtenEvaluation.value = null
            val result = repository.evaluateWritten(course, topicTitle, question, answer)
            _isEvaluatingWritten.value = false
            result.onSuccess { eval ->
                _writtenEvaluation.value = eval
                val xp = eval.score * 10
                val coins = eval.score * 3
                repository.rewardXpAndCoins(course.id, xp, coins)
                grantReward("Answer Evaluated!", xp, coins, "Score: ${eval.score}/${eval.maxScore}")
            }
        }
    }

    // Flashcards Flow
    fun loadFlashcards(topicTitle: String) {
        val course = activeCourse.value ?: return
        viewModelScope.launch {
            _currentFlashcardIndex.value = 0
            _isCardFlipped.value = false
            val result = repository.fetchFlashcards(course, topicTitle)
            result.onSuccess { cards ->
                _flashcards.value = cards
            }
        }
    }

    fun flipCard() {
        _isCardFlipped.value = !_isCardFlipped.value
    }

    fun nextCard() {
        val cards = _flashcards.value
        if (_currentFlashcardIndex.value + 1 < cards.size) {
            _currentFlashcardIndex.value += 1
            _isCardFlipped.value = false
        }
    }

    fun prevCard() {
        if (_currentFlashcardIndex.value > 0) {
            _currentFlashcardIndex.value -= 1
            _isCardFlipped.value = false
        }
    }

    // AI Tutor Chat Flow
    fun setChatInput(text: String) {
        _chatInput.value = text
    }

    fun sendChatMessage(presetMessage: String? = null) {
        val messageToSend = presetMessage ?: _chatInput.value.trim()
        if (messageToSend.isBlank()) return

        val course = activeCourse.value ?: return
        _chatInput.value = ""
        viewModelScope.launch {
            _isTutorTyping.value = true
            repository.askTutor(course, messageToSend)
            _isTutorTyping.value = false
        }
    }

    fun dismissRewardDialog() {
        _rewardDialog.value = null
    }

    private fun grantReward(title: String, xp: Int, coins: Int, msg: String) {
        _rewardDialog.value = RewardData(title, xp, coins, msg)
    }

    override fun onCleared() {
        super.onCleared()
        rapidFireJob?.cancel()
    }
}
