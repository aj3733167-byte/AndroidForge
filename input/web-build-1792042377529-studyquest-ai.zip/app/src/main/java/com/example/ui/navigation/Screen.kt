package com.example.ui.navigation

sealed class Screen {
    object Welcome : Screen()
    data class Dashboard(val initialTab: Int = 0) : Screen()
    object SyllabusUpload : Screen()
    data class LearnLesson(val topicId: String) : Screen()
    data class QuizBattle(val topicId: String, val mode: GameMode = GameMode.QUIZ_BATTLE) : Screen()
    data class WrittenChallenge(val topicId: String) : Screen()
    data class FlashcardRevision(val topicId: String) : Screen()
    object ExamPrep : Screen()
    object SettingsApiKey : Screen()
}

enum class GameMode(val displayName: String, val description: String) {
    QUIZ_BATTLE("Quiz Battle", "4-choice questions, instant feedback & XP"),
    LEVEL_MAP("Level Map", "Explore syllabus chapters and unlock topics"),
    BOSS_BATTLE("Boss Battle", "High-stakes topic mastery exam against the Boss"),
    SURVIVAL("Survival Mode", "3 hearts. Keep answering until you run out!"),
    RAPID_FIRE("Rapid Fire", "Fast-paced questions with a 15-second countdown timer"),
    WRITTEN_CHALLENGE("Written Challenge", "Type descriptive answers evaluated by AI rubric")
}
