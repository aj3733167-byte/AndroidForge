package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.remote.GeminiClient
import com.example.ui.theme.QuestCyan
import com.example.ui.theme.QuestEmerald
import com.example.ui.theme.QuestGold
import com.example.ui.theme.QuestIndigo
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950
import com.example.ui.viewmodel.StudyQuestViewModel
import kotlinx.coroutines.launch

@Composable
fun SettingsApiKeyScreen(
    viewModel: StudyQuestViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val isConnected by viewModel.isApiKeyConfigured.collectAsState()
    var inputKey by remember { mutableStateOf("") }
    var testResult by remember { mutableStateOf<String?>(null) }
    var isTesting by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Slate900)
                .padding(horizontal = 8.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_button")) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "AI Connection Settings",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Gemini AI API Configuration",
                    fontSize = 12.sp,
                    color = QuestCyan
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Connection Status Banner
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isConnected) Color(0xFF065F46) else Color(0xFF7F1D1D)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isConnected) Icons.Default.CheckCircle else Icons.Default.Key,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (isConnected) "Gemini AI Connected" else "API Key Configuration Required",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.White
                        )
                        Text(
                            text = if (isConnected) "Live AI reasoning, syllabus extraction, and smart tutoring are active." else "Set up your Google Gemini API key to enable live AI features.",
                            fontSize = 12.sp,
                            color = Color(0xFFE2E8F0)
                        )
                    }
                }
            }

            // How it works instruction card
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Slate900),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = QuestGold, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Secure Key Architecture", fontWeight = FontWeight.Bold, color = QuestGold, fontSize = 14.sp)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "1. AI Studio Secrets Panel: In Google AI Studio, open the Secrets panel on the left sidebar and configure GEMINI_API_KEY. It is automatically injected securely at runtime.\n\n2. Direct App Key: Alternatively, you can paste your Gemini API key below to test it immediately inside the application.",
                        fontSize = 13.sp,
                        color = Color.LightGray,
                        lineHeight = 20.sp
                    )
                }
            }

            // Direct Key Input
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Slate900),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("ENTER OR OVERRIDE GEMINI API KEY", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = QuestCyan)
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = inputKey,
                        onValueChange = { inputKey = it },
                        placeholder = { Text("AIzaSy...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("api_key_input_field"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = QuestIndigo,
                            unfocusedBorderColor = Slate800,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Slate950,
                            unfocusedContainerColor = Slate950
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (inputKey.isNotBlank()) {
                                viewModel.saveCustomApiKey(inputKey)
                                testResult = "Key saved! You can now test the connection below."
                            }
                        },
                        enabled = inputKey.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = QuestIndigo),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Save Key in App", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Test Connection Button
            Button(
                onClick = {
                    isTesting = true
                    testResult = null
                    scope.launch {
                        val keyToTest = if (inputKey.isNotBlank()) inputKey else viewModel.activeCourse.value?.let { "" } ?: ""
                        // Call test ping
                        val result = GeminiClient.executePrompt(
                            apiKey = if (inputKey.isNotBlank()) inputKey else "MY_GEMINI_API_KEY",
                            prompt = "Reply with 'StudyQuest AI Connected' if you receive this."
                        )
                        isTesting = false
                        testResult = result.fold(
                            onSuccess = { "Success! AI says: $it" },
                            onFailure = { "Test error: ${it.message}" }
                        )
                    }
                },
                enabled = !isTesting,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("test_ai_connection_button"),
                colors = ButtonDefaults.buttonColors(containerColor = Slate800),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isTesting) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Testing AI ping...")
                } else {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = QuestGold)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Test Live Gemini AI Connection", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }

            if (!testResult.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (testResult!!.startsWith("Success")) Color(0xFF065F46) else Color(0xFF7F1D1D),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = testResult!!,
                        color = Color.White,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
