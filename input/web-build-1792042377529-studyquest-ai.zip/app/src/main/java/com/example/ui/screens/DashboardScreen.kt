package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChapterEntity
import com.example.data.model.CourseEntity
import com.example.data.model.MistakeEntity
import com.example.data.model.TopicEntity
import com.example.ui.components.GameHeader
import com.example.ui.navigation.GameMode
import com.example.ui.theme.QuestCyan
import com.example.ui.theme.QuestEmerald
import com.example.ui.theme.QuestGold
import com.example.ui.theme.QuestIndigo
import com.example.ui.theme.QuestPink
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950
import com.example.ui.viewmodel.StudyQuestViewModel

@Composable
fun DashboardScreen(
    viewModel: StudyQuestViewModel,
    activeCourse: CourseEntity?,
    allCourses: List<CourseEntity>,
    chapters: List<ChapterEntity>,
    topics: List<TopicEntity>,
    weakTopics: List<TopicEntity>,
    mistakes: List<MistakeEntity>,
    activeTab: Int,
    isApiKeyConfigured: Boolean,
    onTabSelected: (Int) -> Unit,
    onSelectTopicToLearn: (String) -> Unit,
    onStartGame: (String, GameMode) -> Unit,
    onStartExamPrep: () -> Unit,
    onOpenSyllabusUpload: () -> Unit,
    onOpenApiKeySettings: () -> Unit
) {
    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = Slate900,
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("dashboard_bottom_bar")
            ) {
                NavigationBarItem(
                    selected = activeTab == 0,
                    onClick = { onTabSelected(0) },
                    icon = { Icon(Icons.Default.School, contentDescription = "Learn") },
                    label = { Text("Learn") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = QuestIndigo,
                        indicatorColor = QuestIndigo.copy(alpha = 0.2f),
                        selectedTextColor = Color.White,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    ),
                    modifier = Modifier.testTag("nav_item_learn")
                )
                NavigationBarItem(
                    selected = activeTab == 1,
                    onClick = { onTabSelected(1) },
                    icon = { Icon(Icons.Default.SportsEsports, contentDescription = "Game") },
                    label = { Text("Game") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = QuestPink,
                        indicatorColor = QuestPink.copy(alpha = 0.2f),
                        selectedTextColor = Color.White,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    ),
                    modifier = Modifier.testTag("nav_item_game")
                )
                NavigationBarItem(
                    selected = activeTab == 2,
                    onClick = { onTabSelected(2) },
                    icon = { Icon(Icons.Default.Refresh, contentDescription = "Revision") },
                    label = { Text("Revision") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = QuestGold,
                        indicatorColor = QuestGold.copy(alpha = 0.2f),
                        selectedTextColor = Color.White,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    ),
                    modifier = Modifier.testTag("nav_item_revision")
                )
                NavigationBarItem(
                    selected = activeTab == 3,
                    onClick = { onTabSelected(3) },
                    icon = { Icon(Icons.Default.Psychology, contentDescription = "AI Teacher") },
                    label = { Text("AI Teacher") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = QuestCyan,
                        indicatorColor = QuestCyan.copy(alpha = 0.2f),
                        selectedTextColor = Color.White,
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    ),
                    modifier = Modifier.testTag("nav_item_ai_teacher")
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Slate950)
                .padding(paddingValues)
        ) {
            // Persistent Game Header
            GameHeader(
                activeCourse = activeCourse,
                allCourses = allCourses,
                isApiKeyConfigured = isApiKeyConfigured,
                onSelectCourse = { viewModel.switchCourse(it) },
                onNewCourseClick = onOpenSyllabusUpload,
                onApiKeyClick = onOpenApiKeySettings
            )

            // Switch content based on activeTab
            when (activeTab) {
                0 -> LearnTabContent(
                    activeCourse = activeCourse,
                    chapters = chapters,
                    topics = topics,
                    weakTopics = weakTopics,
                    onSelectTopic = onSelectTopicToLearn,
                    onOpenExamPrep = onStartExamPrep,
                    onOpenUpload = onOpenSyllabusUpload
                )
                1 -> GameTabContent(
                    activeCourse = activeCourse,
                    topics = topics,
                    onStartGameMode = onStartGame
                )
                2 -> RevisionTabContent(
                    activeCourse = activeCourse,
                    mistakes = mistakes,
                    weakTopics = weakTopics,
                    topics = topics,
                    onReviseMistake = { mistakeId ->
                        val topicId = topics.firstOrNull()?.id ?: ""
                        onStartGame(topicId, GameMode.QUIZ_BATTLE)
                    },
                    onReviseWeakTopic = { topicId ->
                        onSelectTopicToLearn(topicId)
                    },
                    onStartDailyChallenge = {
                        val topicId = topics.firstOrNull()?.id ?: ""
                        onStartGame(topicId, GameMode.RAPID_FIRE)
                    }
                )
                3 -> AiTeacherTabContent(
                    activeCourse = activeCourse,
                    viewModel = viewModel
                )
            }
        }
    }
}

@Composable
private fun LearnTabContent(
    activeCourse: CourseEntity?,
    chapters: List<ChapterEntity>,
    topics: List<TopicEntity>,
    weakTopics: List<TopicEntity>,
    onSelectTopic: (String) -> Unit,
    onOpenExamPrep: () -> Unit,
    onOpenUpload: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Daily Goal & Overall Progress
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Slate900),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("TODAY'S LEARNING GOAL", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = QuestGold)
                            Text("Master 2 Topics in ${activeCourse?.subject ?: "Syllabus"}", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = QuestIndigo.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "${activeCourse?.completedTopics ?: 0} / ${activeCourse?.totalTopics ?: 1} Done",
                                color = QuestCyan,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    val completionRate = if ((activeCourse?.totalTopics ?: 0) > 0) {
                        (activeCourse!!.completedTopics.toFloat() / activeCourse.totalTopics.toFloat())
                    } else 0f

                    LinearProgressIndicator(
                        progress = { completionRate },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = QuestEmerald,
                        trackColor = Slate800
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${(completionRate * 100).toInt()}% of complete syllabus mastered",
                        fontSize = 12.sp,
                        color = Color.LightGray
                    )
                }
            }
        }

        // Weak Topics Alert Card (if any)
        if (weakTopics.isNotEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF451A03)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = QuestGold, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Weak Topics Flagged", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                            Text("${weakTopics.first().title} needs revision", fontSize = 12.sp, color = Color(0xFFFDE68A))
                        }
                        Button(
                            onClick = { onSelectTopic(weakTopics.first().id) },
                            colors = ButtonDefaults.buttonColors(containerColor = QuestGold),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text("Revise", fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Exam Preparation Action Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Slate800),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenExamPrep() }
                    .testTag("exam_prep_banner")
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(QuestIndigo.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.FitnessCenter, contentDescription = null, tint = QuestCyan, modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Exam Preparation & Mock Tests", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                        Text("Timed tests, chapter tests, mark distribution rubric", fontSize = 12.sp, color = Color.LightGray)
                    }
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = QuestCyan)
                }
            }
        }

        // Chapters & Topics List
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SYLLABUS CHAPTERS & LESSONS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = QuestGold
                )
                Text(
                    text = "+ Add Syllabus",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = QuestCyan,
                    modifier = Modifier.clickable { onOpenUpload() }
                )
            }
        }

        items(chapters) { chapter ->
            val chapterTopics = topics.filter { it.chapterId == chapter.id }
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Slate900),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Chapter ${chapter.chapterNumber}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = QuestPink
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Slate800
                        ) {
                            Text(
                                text = "${chapterTopics.count { it.status == "MASTERED" }} / ${chapterTopics.size} Mastered",
                                fontSize = 10.sp,
                                color = Color.LightGray,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = chapter.title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    if (chapter.description.isNotBlank()) {
                        Text(
                            text = chapter.description,
                            fontSize = 12.sp,
                            color = Color.LightGray,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Topic Items in this Chapter
                    chapterTopics.forEach { topic ->
                        TopicRowItem(topic = topic, onClick = { onSelectTopic(topic.id) })
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun TopicRowItem(
    topic: TopicEntity,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Slate800,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("topic_item_${topic.id}")
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                val statusColor = when (topic.status) {
                    "MASTERED" -> QuestEmerald
                    "IN_PROGRESS" -> QuestGold
                    else -> QuestIndigo
                }

                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(statusColor.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (topic.status == "MASTERED") Icons.Default.CheckCircle else Icons.Default.School,
                        contentDescription = null,
                        tint = statusColor,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = topic.title,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = Color.White,
                        maxLines = 1
                    )
                    Text(
                        text = "${topic.difficulty} • ${topic.status.replace("_", " ")}",
                        fontSize = 11.sp,
                        color = Color.LightGray
                    )
                }
            }

            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = "Teach me",
                tint = QuestCyan,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun GameTabContent(
    activeCourse: CourseEntity?,
    topics: List<TopicEntity>,
    onStartGameMode: (String, GameMode) -> Unit
) {
    val firstTopicId = topics.firstOrNull()?.id ?: ""

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "INTERACTIVE GAME MODES",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = QuestGold
            )
        }

        // Quiz Battle
        item {
            GameModeCard(
                mode = GameMode.QUIZ_BATTLE,
                badgeColor = QuestIndigo,
                badgeText = "CLASSIC",
                onClick = { onStartGameMode(firstTopicId, GameMode.QUIZ_BATTLE) }
            )
        }

        // Boss Battle
        item {
            GameModeCard(
                mode = GameMode.BOSS_BATTLE,
                badgeColor = Color(0xFFDC2626),
                badgeText = "HIGH STAKES",
                onClick = { onStartGameMode(firstTopicId, GameMode.BOSS_BATTLE) }
            )
        }

        // Survival Mode
        item {
            GameModeCard(
                mode = GameMode.SURVIVAL,
                badgeColor = QuestPink,
                badgeText = "3 HEARTS",
                onClick = { onStartGameMode(firstTopicId, GameMode.SURVIVAL) }
            )
        }

        // Rapid Fire
        item {
            GameModeCard(
                mode = GameMode.RAPID_FIRE,
                badgeColor = QuestGold,
                badgeText = "15s COUNTDOWN",
                onClick = { onStartGameMode(firstTopicId, GameMode.RAPID_FIRE) }
            )
        }

        // Written Answer Challenge
        item {
            GameModeCard(
                mode = GameMode.WRITTEN_CHALLENGE,
                badgeColor = QuestCyan,
                badgeText = "AI RUBRIC GRADING",
                onClick = { onStartGameMode(firstTopicId, GameMode.WRITTEN_CHALLENGE) }
            )
        }
    }
}

@Composable
private fun GameModeCard(
    mode: GameMode,
    badgeColor: Color,
    badgeText: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("game_mode_${mode.name}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Slate900)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = badgeColor.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = badgeText,
                        color = badgeColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = QuestGold, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("+XP & Coins", color = QuestGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = mode.displayName,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Text(
                text = mode.description,
                fontSize = 13.sp,
                color = Color.LightGray,
                modifier = Modifier.padding(top = 2.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onClick,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = badgeColor),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Play ${mode.displayName}", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun RevisionTabContent(
    activeCourse: CourseEntity?,
    mistakes: List<MistakeEntity>,
    weakTopics: List<TopicEntity>,
    topics: List<TopicEntity>,
    onReviseMistake: (String) -> Unit,
    onReviseWeakTopic: (String) -> Unit,
    onStartDailyChallenge: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Daily Challenge Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onStartDailyChallenge() }
                    .testTag("daily_revision_challenge_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B4B))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(QuestGold.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.LocalFireDepartment, contentDescription = null, tint = QuestGold, modifier = Modifier.size(26.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Daily Revision Challenge", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                        Text("5 questions tailored from your past performance", fontSize = 12.sp, color = QuestCyan)
                    }
                    Button(
                        onClick = onStartDailyChallenge,
                        colors = ButtonDefaults.buttonColors(containerColor = QuestGold),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Start", fontWeight = FontWeight.Bold, color = Color.Black)
                    }
                }
            }
        }

        // Saved Mistakes Section (Rule 9)
        item {
            Text(
                text = "REVISE MY MISTAKES (${mistakes.size})",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = QuestGold
            )
        }

        if (mistakes.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Slate900,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = QuestEmerald, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No Mistakes Recorded!", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                        Text("Play quizzes to test your knowledge. Any incorrect answer is automatically logged here with a step-by-step concept breakdown.", color = Color.LightGray, fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
            }
        } else {
            items(mistakes) { mistake ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Slate900)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(mistake.topicTitle, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = QuestPink)
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color(0xFF7F1D1D)
                            ) {
                                Text("Needs Revision", fontSize = 10.sp, color = Color(0xFFFECACA), modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(mistake.question, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Color.White)

                        Spacer(modifier = Modifier.height(8.dp))
                        Row {
                            Text("Your Answer: ", fontSize = 12.sp, color = Color.Red, fontWeight = FontWeight.Bold)
                            Text(mistake.userAnswer, fontSize = 12.sp, color = Color.LightGray)
                        }
                        Row {
                            Text("Correct Answer: ", fontSize = 12.sp, color = QuestEmerald, fontWeight = FontWeight.Bold)
                            Text(mistake.correctAnswer, fontSize = 12.sp, color = Color.White)
                        }

                        if (mistake.conceptExplanation.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Slate800,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "💡 Concept: ${mistake.conceptExplanation}",
                                    fontSize = 12.sp,
                                    color = Color.LightGray,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }

                        if (mistake.memoryTrick.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "⚡ Memory Trick: ${mistake.memoryTrick}",
                                fontSize = 12.sp,
                                color = QuestGold,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { onReviseMistake(mistake.id) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = QuestIndigo),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Practice This Question Again", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AiTeacherTabContent(
    activeCourse: CourseEntity?,
    viewModel: StudyQuestViewModel
) {
    AiTeacherScreen(
        viewModel = viewModel,
        activeCourse = activeCourse
    )
}
