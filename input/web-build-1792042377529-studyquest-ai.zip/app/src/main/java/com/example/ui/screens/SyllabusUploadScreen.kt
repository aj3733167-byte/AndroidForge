package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.QuestCyan
import com.example.ui.theme.QuestEmerald
import com.example.ui.theme.QuestGold
import com.example.ui.theme.QuestIndigo
import com.example.ui.theme.QuestPink
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950
import com.example.ui.viewmodel.StudyQuestViewModel
import java.io.ByteArrayOutputStream

@Composable
fun SyllabusUploadScreen(
    viewModel: StudyQuestViewModel,
    isUploading: Boolean,
    errorMessage: String?,
    onBack: () -> Unit,
    onSuccess: () -> Unit
) {
    val context = LocalContext.current
    var courseTitle by remember { mutableStateOf("") }
    var syllabusText by remember { mutableStateOf("") }
    var selectedImageBase64 by remember { mutableStateOf<String?>(null) }
    var selectedImageName by remember { mutableStateOf<String?>(null) }

    // Android Zero-permission Photo Picker
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                val outputStream = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
                val bytes = outputStream.toByteArray()
                selectedImageBase64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                selectedImageName = "Syllabus_Photo.jpg (${bytes.size / 1024} KB)"
            } catch (e: Exception) {
                // handle gracefully
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
    ) {
        // Top App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Slate900)
                .padding(horizontal = 8.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("upload_back_button")
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "Upload Syllabus",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "AI will automatically structure chapters and lessons",
                    fontSize = 12.sp,
                    color = Color.LightGray
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Quick Sample Syllabi Shortcuts
            Text(
                text = "QUICK LOAD SAMPLE SYLLABI",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = QuestGold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SampleChip(
                    title = "Class 10 Hindi & Sanskrit",
                    icon = Icons.Default.Translate,
                    color = QuestPink,
                    modifier = Modifier.weight(1f)
                ) {
                    courseTitle = "Class 10 Hindi & Sanskrit"
                    syllabusText = """
CBSE Class 10 Hindi Course A Syllabus:
1. Kshitij Part 2:
   - Surdas ke Pad
   - Tulsidas: Ram-Lakshman-Parshuram Samvad
   - Netaji ka Chashma (Swayam Prakash)
   - Balgobin Bhagat (Ramvriksh Benipuri)
2. Vyakaran (Grammar):
   - Rachna ke aadhar par Vakya Bhed (Saral, Sanyukt, Mishra)
   - Vachya (Kartrivachya, Karmavachya, Bhavavachya)
   - Pad Parichay (Sangnya, Sarvanam, Visheshan, Kriya, Karak)
   - Alankar (Shlesh, Utpreksha, Atishyokti, Manavikaran)
3. Sanskrit Core:
   - Sandhi (Swar, Visarga)
   - Samas (Tatpurush, Karmadharay, Dvigu, Bahuvrihi)
""".trimIndent()
                }

                SampleChip(
                    title = "Class 10 Math",
                    icon = Icons.Default.Calculate,
                    color = QuestCyan,
                    modifier = Modifier.weight(1f)
                ) {
                    courseTitle = "Class 10 Mathematics"
                    syllabusText = """
Class 10 Mathematics NCERT:
1. Real Numbers: Fundamental Theorem of Arithmetic, Proofs of irrationality of sqrt(2), sqrt(3), sqrt(5).
2. Polynomials: Zeros of polynomial, Relationship between zeros and coefficients of quadratic polynomials.
3. Pair of Linear Equations in Two Variables: Graphical and algebraic methods (substitution, elimination).
4. Quadratic Equations: Standard form ax^2 + bx + c = 0, solutions by factorization and quadratic formula.
5. Arithmetic Progressions: nth term and sum of first n terms of AP.
6. Triangles: Basic Proportionality Theorem (Thales), Criteria for similarity (AAA, SSS, SAS).
7. Introduction to Trigonometry: Trigonometric ratios of acute angles, Values (30, 45, 60), Trigonometric identities (sin^2 + cos^2 = 1).
""".trimIndent()
                }

                SampleChip(
                    title = "Science / Physics",
                    icon = Icons.Default.Science,
                    color = QuestEmerald,
                    modifier = Modifier.weight(1f)
                ) {
                    courseTitle = "Physics & Chemistry Core"
                    syllabusText = """
Science Class 10 / 12 Foundations:
1. Light - Reflection and Refraction: Spherical mirrors, Mirror formula, Refractive index, Lens formula, Power of lens.
2. Electricity: Ohm's law, Resistance, Series and parallel combinations, Heating effect of electric current (Joule's law).
3. Magnetic Effects of Electric Current: Magnetic field lines, Right-hand thumb rule, Fleming's left-hand rule.
4. Chemical Reactions and Equations: Types of chemical reactions, Balancing equations, Oxidation and Reduction.
""".trimIndent()
                }
            }

            // Course Name Input
            OutlinedTextField(
                value = courseTitle,
                onValueChange = { courseTitle = it },
                label = { Text("Course Title (Optional)") },
                placeholder = { Text("e.g. Class 10 Hindi, UPSC History, AP Biology") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("course_title_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = QuestIndigo,
                    unfocusedBorderColor = Slate800,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = Slate900,
                    unfocusedContainerColor = Slate900
                ),
                shape = RoundedCornerShape(12.dp)
            )

            // Syllabus Photo / Document Picker Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }
                    .testTag("upload_photo_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Slate900)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(QuestPink.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = "Upload Photo",
                            tint = QuestPink,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (selectedImageName != null) "Photo Selected" else "Upload Textbook / Syllabus Photo",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.White
                        )
                        Text(
                            text = selectedImageName ?: "Tap to choose photo of syllabus or textbook page",
                            fontSize = 12.sp,
                            color = if (selectedImageName != null) QuestEmerald else Color.LightGray
                        )
                    }

                    if (selectedImageName != null) {
                        IconButton(onClick = {
                            selectedImageBase64 = null
                            selectedImageName = null
                        }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear Photo", tint = Color.Red)
                        }
                    }
                }
            }

            // Raw Syllabus Text Field
            Text(
                text = "OR PASTE SYLLABUS / CHAPTER LIST",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = QuestCyan
            )

            OutlinedTextField(
                value = syllabusText,
                onValueChange = { syllabusText = it },
                label = { Text("Syllabus Content, Chapters, or Notes") },
                placeholder = { Text("Paste chapter names, topic lists, rules, or curriculum text here...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .testTag("syllabus_text_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = QuestIndigo,
                    unfocusedBorderColor = Slate800,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = Slate900,
                    unfocusedContainerColor = Slate900
                ),
                shape = RoundedCornerShape(12.dp)
            )

            // Error notice if any
            if (!errorMessage.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF7F1D1D),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Error: $errorMessage",
                        color = Color.White,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Submit Button
            Button(
                onClick = {
                    val finalTitle = courseTitle.ifBlank { "New Course" }
                    val finalInput = syllabusText.ifBlank { "Comprehensive examination syllabus" }
                    viewModel.uploadSyllabus(
                        title = finalTitle,
                        text = finalInput,
                        imageBase64 = selectedImageBase64,
                        onSuccess = onSuccess
                    )
                },
                enabled = !isUploading && (syllabusText.isNotBlank() || selectedImageBase64 != null),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("extract_syllabus_button"),
                colors = ButtonDefaults.buttonColors(containerColor = QuestIndigo),
                shape = RoundedCornerShape(16.dp)
            ) {
                if (isUploading) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("AI Extracting Syllabus Structure...", fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = QuestGold)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Analyze & Create Course with AI", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SampleChip(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Slate900)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 2
            )
        }
    }
}
